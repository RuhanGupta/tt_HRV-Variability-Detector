`timescale 1ns/1ps

module tb ();

    reg clk;
    reg rst_n;
    reg sda_in;

    wire cmd_valid, cmd_type_w0, cmd_type_w1;
    wire [1:0] cmd_type;
    wire [7:0] tx_byte;
    wire read_ack_value;
    wire cmd_ready, cmd_done;
    wire [7:0] rx_byte;
    wire ack_received;
    wire i2c_error;
    wire sda_drive_low, scl_drive_low;

    wire i2c_tick;

    wire [17:0] raw_sample;
    wire sample_valid;
    wire sensor_fault;
    wire init_done;

    initial begin
        $dumpfile("tb.fst");
        $dumpvars(0, tb);
    end

    tick_generator #(.F_clk(1_000_000)) u_tick (
        .clk(clk),
        .rst_n(rst_n),
        .i2c_tick(i2c_tick)
    );

    i2c_byte_engine u_i2c (
        .clk(clk),
        .rst_n(rst_n),
        .i2c_tick(i2c_tick),
        .cmd_valid(cmd_valid),
        .cmd_type(cmd_type),
        .tx_byte(tx_byte),
        .read_ack_value(read_ack_value),
        .sda_in(sda_in),
        .cmd_ready(cmd_ready),
        .cmd_done(cmd_done),
        .rx_byte(rx_byte),
        .ack_received(ack_received),
        .i2c_error(i2c_error),
        .sda_drive_low(sda_drive_low),
        .scl_drive_low(scl_drive_low)
    );

    max30102_controller u_max (
        .clk(clk),
        .rst_n(rst_n),
        .cmd_valid(cmd_valid),
        .cmd_type(cmd_type),
        .tx_byte(tx_byte),
        .read_ack_value(read_ack_value),
        .cmd_ready(cmd_ready),
        .cmd_done(cmd_done),
        .rx_byte(rx_byte),
        .ack_received(ack_received),
        .i2c_error(i2c_error),
        .raw_sample(raw_sample),
        .sample_valid(sample_valid),
        .sensor_fault(sensor_fault),
        .init_done(init_done)
    );

endmodule
