module max30102_controller (
    input  wire        clk,
    input  wire        rst_n,

    // command interface to i2c_byte_engine
    output reg         cmd_valid,
    output reg  [1:0]  cmd_type,
    output reg  [7:0]  tx_byte,
    output reg         read_ack_value,
    input  wire        cmd_ready,
    input  wire        cmd_done,
    input  wire [7:0]  rx_byte,
    input  wire        ack_received,
    input  wire        i2c_error,

    // outputs to the rest of the chip
    output reg  [17:0] raw_sample,
    output reg         sample_valid,
    output reg         sensor_fault,
    output reg         init_done
);

    // ---- i2c_byte_engine command encoding (must match i2c_byte_engine.v) ----
    localparam CMD_START      = 2'd0;
    localparam CMD_STOP       = 2'd1;
    localparam CMD_WRITE_BYTE = 2'd2;
    localparam CMD_READ_BYTE  = 2'd3;

    // ---- MAX30102 constants, confirmed against the datasheet ----
    localparam [7:0] ADDR_WRITE = 8'hAE;
    localparam [7:0] ADDR_READ  = 8'hAF;

    localparam [7:0] REG_FIFO_WR_PTR   = 8'h04;
    localparam [7:0] REG_OVF_COUNTER   = 8'h05;
    localparam [7:0] REG_FIFO_RD_PTR   = 8'h06;
    localparam [7:0] REG_FIFO_DATA     = 8'h07;
    localparam [7:0] REG_FIFO_CONFIG   = 8'h08;
    localparam [7:0] REG_MODE_CONFIG   = 8'h09;
    localparam [7:0] REG_SPO2_CONFIG   = 8'h0A;
    localparam [7:0] REG_LED2_PA       = 8'h0D;  // IR current: slot1=LED2=IR, so LED2_PA, not LED1_PA
    localparam [7:0] REG_SLOT_CONFIG   = 8'h11;
    localparam [7:0] REG_PART_ID       = 8'hFF;

    localparam [7:0] PART_ID_EXPECTED  = 8'h15;
    localparam [7:0] MODE_RESET_CMD    = 8'h40;  // RESET bit set
    localparam [7:0] MODE_MULTI_LED    = 8'h07;  // SHDN=0, RESET=0, MODE=111

    // provisional, pending real ESP32 characterization data:
    localparam [7:0] FIFO_CONFIG_VALUE  = 8'h10;  // no averaging, rollover enabled
    localparam [7:0] SPO2_CONFIG_VALUE  = 8'h27;  // ADC_RGE=01(placeholder), SR=100sps, PW=411us/18-bit
    localparam [7:0] LED2_CURRENT_VALUE = 8'h24;  // placeholder IR current
    localparam [7:0] SLOT_CONFIG_VALUE  = 8'h02;  // slot1 = IR (LED2)

    localparam POWER_WAIT_CYCLES = 16;            // placeholder startup delay

    // ---- top-level FSM states ----
    localparam S_POWER_WAIT           = 5'd0;
    localparam S_CHECK_PART_ID        = 5'd1;
    localparam S_POLL_RESET_SETUP     = 5'd2;
    localparam S_POLL_RESET_CHECK     = 5'd3;
    localparam S_INIT_WRITE_SETUP     = 5'd4;
    localparam S_INIT_WRITE_NEXT      = 5'd5;
    localparam S_RUNTIME_POLL_SETUP   = 5'd6;
    localparam S_RUNTIME_POLL_CHECK   = 5'd7;
    localparam S_RUNTIME_SAMPLE_READY = 5'd8;
    localparam S_FAULT_HALT           = 5'd9;

    // shared WRITE_REG sub-sequence: START, addr(W), reg, value, STOP
    localparam S_WRITE_REG_START    = 5'd10;
    localparam S_WRITE_REG_ADDR     = 5'd11;
    localparam S_WRITE_REG_REGADDR  = 5'd12;
    localparam S_WRITE_REG_VALUE    = 5'd13;
    localparam S_WRITE_REG_STOP     = 5'd14;

    // shared READ_REG sub-sequence: START, addr(W), reg, Sr, addr(R), byte(s), STOP
    localparam S_READ_REG_START     = 5'd15;
    localparam S_READ_REG_ADDRW     = 5'd16;
    localparam S_READ_REG_REGADDR   = 5'd17;
    localparam S_READ_REG_RSTART    = 5'd18;
    localparam S_READ_REG_ADDRR     = 5'd19;
    localparam S_READ_REG_BYTE      = 5'd20;
    localparam S_READ_REG_STOP      = 5'd21;

    reg [4:0] state;
    reg [4:0] return_state;

    // parameters for the shared sub-sequences
    reg [7:0] seq_reg_addr;
    reg [7:0] seq_write_value;
    reg [1:0] seq_read_count;   // 1 or 3
    reg [1:0] seq_byte_index;
    reg [7:0] seq_rx0, seq_rx1, seq_rx2;

    reg [7:0]  power_wait_counter;
    reg [2:0]  init_write_index;
    reg [4:0]  rd_ptr;
    reg [4:0]  samples_remaining;

    // ============================================================
    // Command outputs are PURELY COMBINATIONAL functions of `state`.
    // This is deliberate: if these were assigned inside the sequential
    // block on a per-state basis, the last cycle of a finishing state
    // would still be re-driving that state's OLD command value (Verilog
    // evaluates the current state's own logic before `state` itself
    // updates), creating a one-cycle window where `state` has already
    // moved on but the command outputs haven't caught up. A fast-enough
    // i2c_tick could land exactly in that window and latch stale data.
    // Deriving these combinationally from `state` makes that impossible:
    // they change in perfect lockstep with `state`, same cycle, always.
    // ============================================================
    always @(*) begin
        cmd_valid      = 1'b0;
        cmd_type       = CMD_START;
        tx_byte        = 8'd0;
        read_ack_value = 1'b0;
        case (state)
            S_WRITE_REG_START:   begin cmd_valid = 1'b1; cmd_type = CMD_START; end
            S_WRITE_REG_ADDR:    begin cmd_valid = 1'b1; cmd_type = CMD_WRITE_BYTE; tx_byte = ADDR_WRITE; end
            S_WRITE_REG_REGADDR: begin cmd_valid = 1'b1; cmd_type = CMD_WRITE_BYTE; tx_byte = seq_reg_addr; end
            S_WRITE_REG_VALUE:   begin cmd_valid = 1'b1; cmd_type = CMD_WRITE_BYTE; tx_byte = seq_write_value; end
            S_WRITE_REG_STOP:    begin cmd_valid = 1'b1; cmd_type = CMD_STOP; end

            S_READ_REG_START:    begin cmd_valid = 1'b1; cmd_type = CMD_START; end
            S_READ_REG_ADDRW:    begin cmd_valid = 1'b1; cmd_type = CMD_WRITE_BYTE; tx_byte = ADDR_WRITE; end
            S_READ_REG_REGADDR:  begin cmd_valid = 1'b1; cmd_type = CMD_WRITE_BYTE; tx_byte = seq_reg_addr; end
            S_READ_REG_RSTART:   begin cmd_valid = 1'b1; cmd_type = CMD_START; end
            S_READ_REG_ADDRR:    begin cmd_valid = 1'b1; cmd_type = CMD_WRITE_BYTE; tx_byte = ADDR_READ; end
            S_READ_REG_BYTE:     begin
                cmd_valid      = 1'b1;
                cmd_type       = CMD_READ_BYTE;
                read_ack_value = (seq_byte_index == seq_read_count - 1'b1) ? 1'b1 : 1'b0;
            end
            S_READ_REG_STOP:     begin cmd_valid = 1'b1; cmd_type = CMD_STOP; end

            default: ; // cmd_valid stays 0: idle, or a bookkeeping-only state
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state              <= S_POWER_WAIT;
            return_state       <= S_POWER_WAIT;
            raw_sample         <= 18'd0;
            sample_valid       <= 1'b0;
            sensor_fault       <= 1'b0;
            init_done          <= 1'b0;
            seq_reg_addr       <= 8'd0;
            seq_write_value    <= 8'd0;
            seq_read_count     <= 2'd0;
            seq_byte_index     <= 2'd0;
            seq_rx0            <= 8'd0;
            seq_rx1            <= 8'd0;
            seq_rx2            <= 8'd0;
            power_wait_counter <= 8'd0;
            init_write_index   <= 3'd0;
            rd_ptr             <= 5'd0;
            samples_remaining  <= 5'd0;
        end
        else begin
            sample_valid <= 1'b0;   // default: pulse only on a completed sample

            case (state)

                // ============== POWER-UP ==============
                S_POWER_WAIT: begin
                    if (power_wait_counter == POWER_WAIT_CYCLES - 1) begin
                        seq_reg_addr   <= REG_PART_ID;
                        seq_read_count <= 2'd1;
                        return_state   <= S_CHECK_PART_ID;
                        state          <= S_READ_REG_START;
                    end else begin
                        power_wait_counter <= power_wait_counter + 1'b1;
                    end
                end

                S_CHECK_PART_ID: begin
                    if (seq_rx0 == PART_ID_EXPECTED) begin
                        seq_reg_addr    <= REG_MODE_CONFIG;
                        seq_write_value <= MODE_RESET_CMD;
                        return_state    <= S_POLL_RESET_SETUP;
                        state           <= S_WRITE_REG_START;
                    end else begin
                        sensor_fault <= 1'b1;
                        state        <= S_FAULT_HALT;
                    end
                end

                // ============== RESET POLLING ==============
                S_POLL_RESET_SETUP: begin
                    seq_reg_addr   <= REG_MODE_CONFIG;
                    seq_read_count <= 2'd1;
                    return_state   <= S_POLL_RESET_CHECK;
                    state          <= S_READ_REG_START;
                end

                S_POLL_RESET_CHECK: begin
                    if (seq_rx0[6]) begin
                        state <= S_POLL_RESET_SETUP;   // still resetting, poll again
                    end else begin
                        init_write_index <= 3'd0;
                        state            <= S_INIT_WRITE_SETUP;
                    end
                end

                // ============== REMAINING INIT WRITES (table-driven) ==============
                S_INIT_WRITE_SETUP: begin
                    return_state <= S_INIT_WRITE_NEXT;
                    state        <= S_WRITE_REG_START;
                    case (init_write_index)
                        3'd0: begin seq_reg_addr <= REG_FIFO_WR_PTR; seq_write_value <= 8'h00; end
                        3'd1: begin seq_reg_addr <= REG_OVF_COUNTER; seq_write_value <= 8'h00; end
                        3'd2: begin seq_reg_addr <= REG_FIFO_RD_PTR; seq_write_value <= 8'h00; end
                        3'd3: begin seq_reg_addr <= REG_FIFO_CONFIG; seq_write_value <= FIFO_CONFIG_VALUE; end
                        3'd4: begin seq_reg_addr <= REG_SPO2_CONFIG; seq_write_value <= SPO2_CONFIG_VALUE; end
                        3'd5: begin seq_reg_addr <= REG_LED2_PA;     seq_write_value <= LED2_CURRENT_VALUE; end
                        3'd6: begin seq_reg_addr <= REG_SLOT_CONFIG; seq_write_value <= SLOT_CONFIG_VALUE; end
                        3'd7: begin seq_reg_addr <= REG_MODE_CONFIG; seq_write_value <= MODE_MULTI_LED; end
                        default: begin seq_reg_addr <= REG_MODE_CONFIG; seq_write_value <= MODE_MULTI_LED; end
                    endcase
                end

                S_INIT_WRITE_NEXT: begin
                    if (init_write_index == 3'd7) begin
                        init_done <= 1'b1;
                        rd_ptr    <= 5'd0;
                        state     <= S_RUNTIME_POLL_SETUP;
                    end else begin
                        init_write_index <= init_write_index + 1'b1;
                        state            <= S_INIT_WRITE_SETUP;
                    end
                end

                // ============== RUNTIME: poll FIFO_WR_PTR ==============
                S_RUNTIME_POLL_SETUP: begin
                    seq_reg_addr   <= REG_FIFO_WR_PTR;
                    seq_read_count <= 2'd1;
                    return_state   <= S_RUNTIME_POLL_CHECK;
                    state          <= S_READ_REG_START;
                end

                S_RUNTIME_POLL_CHECK: begin
                    if (((seq_rx0[4:0] - rd_ptr) & 5'h1F) == 5'd0) begin
                        state <= S_RUNTIME_POLL_SETUP;   // nothing new yet, keep polling
                    end else begin
                        samples_remaining <= (seq_rx0[4:0] - rd_ptr) & 5'h1F;
                        seq_reg_addr      <= REG_FIFO_DATA;
                        seq_read_count    <= 2'd3;
                        return_state      <= S_RUNTIME_SAMPLE_READY;
                        state             <= S_READ_REG_START;
                    end
                end

                S_RUNTIME_SAMPLE_READY: begin
                    raw_sample   <= {seq_rx0[1:0], seq_rx1, seq_rx2};
                    sample_valid <= 1'b1;
                    rd_ptr       <= rd_ptr + 1'b1;
                    if (samples_remaining == 5'd1) begin
                        state <= S_RUNTIME_POLL_SETUP;    // that was the last backlogged sample
                    end else begin
                        samples_remaining <= samples_remaining - 1'b1;
                        seq_reg_addr      <= REG_FIFO_DATA;
                        seq_read_count    <= 2'd3;
                        return_state      <= S_RUNTIME_SAMPLE_READY;
                        state             <= S_READ_REG_START;  // more backlog, read another directly
                    end
                end

                // ============== FAULT ==============
                S_FAULT_HALT: begin
                    // sit here forever; only an external reset recovers
                end

                // ============== SHARED: WRITE_REG(seq_reg_addr, seq_write_value) ==============
                S_WRITE_REG_START: begin
                    if (cmd_done) state <= S_WRITE_REG_ADDR;
                end
                S_WRITE_REG_ADDR: begin
                    if (cmd_done) begin
                        if (!ack_received) begin sensor_fault <= 1'b1; state <= S_FAULT_HALT; end
                        else state <= S_WRITE_REG_REGADDR;
                    end
                end
                S_WRITE_REG_REGADDR: begin
                    if (cmd_done) begin
                        if (!ack_received) begin sensor_fault <= 1'b1; state <= S_FAULT_HALT; end
                        else state <= S_WRITE_REG_VALUE;
                    end
                end
                S_WRITE_REG_VALUE: begin
                    if (cmd_done) begin
                        if (!ack_received) begin sensor_fault <= 1'b1; state <= S_FAULT_HALT; end
                        else state <= S_WRITE_REG_STOP;
                    end
                end
                S_WRITE_REG_STOP: begin
                    if (cmd_done) begin
                        if (!ack_received) begin sensor_fault <= 1'b1; state <= S_FAULT_HALT; end
                        else state <= return_state;
                    end
                end

                // ============== SHARED: READ_REG(seq_reg_addr, seq_read_count) -> seq_rx0/1/2 ==============
                S_READ_REG_START: begin
                    if (cmd_done) state <= S_READ_REG_ADDRW;
                end
                S_READ_REG_ADDRW: begin
                    if (cmd_done) begin
                        if (!ack_received) begin sensor_fault <= 1'b1; state <= S_FAULT_HALT; end
                        else state <= S_READ_REG_REGADDR;
                    end
                end
                S_READ_REG_REGADDR: begin
                    if (cmd_done) begin
                        if (!ack_received) begin sensor_fault <= 1'b1; state <= S_FAULT_HALT; end
                        else state <= S_READ_REG_RSTART;
                    end
                end
                S_READ_REG_RSTART: begin
                    if (cmd_done) state <= S_READ_REG_ADDRR;
                end
                S_READ_REG_ADDRR: begin
                    if (cmd_done) begin
                        if (!ack_received) begin sensor_fault <= 1'b1; state <= S_FAULT_HALT; end
                        else begin
                            seq_byte_index <= 2'd0;
                            state          <= S_READ_REG_BYTE;
                        end
                    end
                end
                S_READ_REG_BYTE: begin
                    if (cmd_done) begin
                        case (seq_byte_index)
                            2'd0: seq_rx0 <= rx_byte;
                            2'd1: seq_rx1 <= rx_byte;
                            2'd2: seq_rx2 <= rx_byte;
                            default: ;
                        endcase
                        if (seq_byte_index == seq_read_count - 1'b1) begin
                            state <= S_READ_REG_STOP;
                        end else begin
                            seq_byte_index <= seq_byte_index + 1'b1;
                            // stays in S_READ_REG_BYTE; the combinational
                            // block above will issue the next READ_BYTE
                            // using the updated seq_byte_index next cycle
                        end
                    end
                end
                S_READ_REG_STOP: begin
                    if (cmd_done) state <= return_state;
                end

                default: state <= S_POWER_WAIT;

            endcase
        end
    end

endmodule
