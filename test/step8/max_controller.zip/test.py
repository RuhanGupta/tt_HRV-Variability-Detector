import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

SLAVE_ADDRESS = 0x57
REG_FIFO_WR_PTR = 0x04
REG_OVF_COUNTER = 0x05
REG_FIFO_RD_PTR = 0x06
REG_FIFO_DATA   = 0x07
REG_FIFO_CONFIG = 0x08
REG_MODE_CONFIG = 0x09
REG_SPO2_CONFIG = 0x0A
REG_LED2_PA     = 0x0D
REG_SLOT_CONFIG = 0x11
REG_PART_ID     = 0xFF

PART_ID_EXPECTED  = 0x15
FIFO_CONFIG_VALUE = 0x10
SPO2_CONFIG_VALUE = 0x27
LED2_CURRENT_VALUE = 0x24
SLOT_CONFIG_VALUE = 0x02
MODE_MULTI_LED    = 0x07


async def start_clock(dut):
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.sda_in.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


class MAX30102Model:
    """A register-aware behavioral MAX30102 model. Reacts to real SDA/SCL
    electrical edges (not a pre-scripted schedule), tracks its own
    register state, and simulates the RESET bit self-clearing and the
    FIFO producing samples over time, the same way a real chip would."""

    def __init__(self, dut, bus_state, address=SLAVE_ADDRESS, part_id=PART_ID_EXPECTED):
        self.dut = dut
        self.bus_state = bus_state
        self.address = address
        self.registers = {
            REG_MODE_CONFIG: 0x00,
            REG_FIFO_WR_PTR: 0x00,
            REG_FIFO_RD_PTR: 0x00,
            REG_OVF_COUNTER: 0x00,
            REG_FIFO_CONFIG: 0x00,
            REG_SPO2_CONFIG: 0x00,
            REG_LED2_PA: 0x00,
            REG_SLOT_CONFIG: 0x00,
            REG_PART_ID: part_id,
        }
        self.reg_pointer = None
        self.fifo_queue = []       # list of 18-bit raw samples waiting to be read
        self.fifo_byte_pos = 0
        self.reset_countdown = 0   # >0 while RESET bit should still read as set
        self.write_log = []        # list of (reg, value) in the order they were written
        self._reset_edge_state()

    def _reset_edge_state(self):
        self.active = False
        self.phase = None
        self.addr_bits = []
        self.data_bits = []
        self.is_read = None
        self.addressed_to_us = False

    # ---- test control helpers ----
    def push_sample(self, value18):
        """Simulate the sensor producing one more sample: append to the
        FIFO and advance FIFO_WR_PTR, exactly as the real chip would."""
        self.fifo_queue.append(value18 & 0x3FFFF)
        self.registers[REG_FIFO_WR_PTR] = (self.registers[REG_FIFO_WR_PTR] + 1) & 0x1F

    def _sample_to_bytes(self, value18):
        b0 = (value18 >> 16) & 0x03   # datasheet: only bits 17:16 live in byte0, left-justified
        b1 = (value18 >> 8) & 0xFF
        b2 = value18 & 0xFF
        return [b0, b1, b2]

    # ---- electrical layer (same approach as i2c_byte_engine's slave model) ----
    def sda_line(self):
        try:
            master = bool(self.dut.sda_drive_low.value)
        except ValueError:
            master = False
        return not (master or self.bus_state["slave_sda_drive_low"])

    def scl_line(self):
        try:
            return not bool(self.dut.scl_drive_low.value)
        except ValueError:
            return True

    async def run(self):
        prev_scl = self.scl_line()
        prev_sda = self.sda_line()
        while True:
            await RisingEdge(self.dut.clk)

            # simulate the RESET bit self-clearing after a short delay
            if self.reset_countdown > 0:
                self.reset_countdown -= 1
                if self.reset_countdown == 0:
                    self.registers[REG_MODE_CONFIG] &= ~0x40

            scl = self.scl_line()
            sda = self.sda_line()

            if scl and prev_scl and prev_sda and not sda:
                self._on_start()
            elif scl and prev_scl and (not prev_sda) and sda:
                self._on_stop()
            elif scl and not prev_scl:
                self._on_scl_rising(sda)
            elif (not scl) and prev_scl:
                self._on_scl_falling()

            prev_scl, prev_sda = scl, sda

    def _on_start(self):
        self.active = True
        self.phase = "ADDR"
        self.addr_bits = []
        self.bus_state["slave_sda_drive_low"] = False

    def _on_stop(self):
        self._reset_edge_state()
        self.reg_pointer = None
        self.bus_state["slave_sda_drive_low"] = False

    def _on_scl_rising(self, sda):
        if not self.active:
            return
        if self.phase == "ADDR":
            self.addr_bits.append(1 if sda else 0)
            if len(self.addr_bits) == 8:
                addr_byte = 0
                for b in self.addr_bits:
                    addr_byte = (addr_byte << 1) | b
                self.is_read = bool(addr_byte & 1)
                self.addressed_to_us = ((addr_byte >> 1) == self.address)
                self.phase = "ADDR_ACK_PENDING"
        elif self.phase == "DATA_WRITE":
            self.data_bits.append(1 if sda else 0)
            if len(self.data_bits) == 8:
                byte_val = 0
                for b in self.data_bits:
                    byte_val = (byte_val << 1) | b
                self._handle_write_byte(byte_val)
                self.phase = "DATA_WRITE_ACK_PENDING"
        elif self.phase == "DATA_READ_SAMPLE_ACK":
            got_ack = not sda
            if got_ack:
                self.phase = "DATA_READ_ARM"
            else:
                self.phase = "DONE_READING"

    def _handle_write_byte(self, byte_val):
        if self.reg_pointer is None:
            self.reg_pointer = byte_val
        else:
            self.write_log.append((self.reg_pointer, byte_val))
            self.registers[self.reg_pointer] = byte_val
            if self.reg_pointer == REG_MODE_CONFIG and (byte_val & 0x40):
                self.reset_countdown = 2000   # long enough to outlast a full I2C transaction

    def _on_scl_falling(self):
        if not self.active:
            return
        if self.phase == "ADDR_ACK_PENDING":
            self.bus_state["slave_sda_drive_low"] = self.addressed_to_us
            self.phase = "ADDR_ACK_DRIVING"
        elif self.phase == "ADDR_ACK_DRIVING":
            self.bus_state["slave_sda_drive_low"] = False
            if not self.addressed_to_us:
                self.phase = "IGNORED"
            elif self.is_read:
                self._arm_read_byte()
            else:
                self.phase = "DATA_WRITE"
                self.data_bits = []
        elif self.phase == "DATA_WRITE_ACK_PENDING":
            self.bus_state["slave_sda_drive_low"] = True
            self.phase = "DATA_WRITE_ACK_DRIVING"
        elif self.phase == "DATA_WRITE_ACK_DRIVING":
            self.bus_state["slave_sda_drive_low"] = False
            self.data_bits = []
            self.phase = "DATA_WRITE"
        elif self.phase == "DATA_READ_ARM":
            self._arm_read_byte()
        elif self.phase == "DATA_READ":
            if self.bit_index < 8:
                self._drive_read_bit()
                if self.bit_index == 8:
                    self.phase = "DATA_READ_LAST_BIT_PENDING"
        elif self.phase == "DATA_READ_LAST_BIT_PENDING":
            self.bus_state["slave_sda_drive_low"] = False
            self.phase = "DATA_READ_SAMPLE_ACK"
        elif self.phase in ("DONE_READING", "IGNORED"):
            self.bus_state["slave_sda_drive_low"] = False

    def _current_read_byte(self):
        """What byte to serve right now, based on the register pointer."""
        if self.reg_pointer == REG_FIFO_DATA:
            if self.fifo_queue:
                sample_bytes = self._sample_to_bytes(self.fifo_queue[0])
                b = sample_bytes[self.fifo_byte_pos]
                self.fifo_byte_pos += 1
                if self.fifo_byte_pos == 3:
                    self.fifo_queue.pop(0)
                    self.fifo_byte_pos = 0
                    self.registers[REG_FIFO_RD_PTR] = (self.registers[REG_FIFO_RD_PTR] + 1) & 0x1F
                return b
            return 0x00
        return self.registers.get(self.reg_pointer, 0x00)

    def _arm_read_byte(self):
        self.bit_index = 0
        self.current_byte = self._current_read_byte()
        self.phase = "DATA_READ"
        self._drive_read_bit()

    def _drive_read_bit(self):
        bit = (self.current_byte >> (7 - self.bit_index)) & 1
        self.bus_state["slave_sda_drive_low"] = (bit == 0)
        self.bit_index += 1


@cocotb.test()
async def test_full_init_and_one_sample(dut):
    """Confirm the full init sequence writes the right values in the right
    order, then completes, then correctly reads back one real sample."""
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}

    async def bus_model():
        while True:
            await RisingEdge(dut.clk)
            try:
                master_drive = bool(dut.sda_drive_low.value)
            except ValueError:
                master_drive = False
            dut.sda_in.value = 0 if (master_drive or bus_state["slave_sda_drive_low"]) else 1

    cocotb.start_soon(bus_model())
    await reset_dut(dut)

    slave = MAX30102Model(dut, bus_state)
    cocotb.start_soon(slave.run())

    # wait for init to complete
    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.init_done.value == 1:
            break
    assert dut.init_done.value == 1, "init never completed"
    assert dut.sensor_fault.value == 0, "sensor_fault should not be set on a clean init"

    expected_writes = [
        (REG_MODE_CONFIG, 0x40),           # reset trigger
        (REG_FIFO_WR_PTR, 0x00),
        (REG_OVF_COUNTER, 0x00),
        (REG_FIFO_RD_PTR, 0x00),
        (REG_FIFO_CONFIG, FIFO_CONFIG_VALUE),
        (REG_SPO2_CONFIG, SPO2_CONFIG_VALUE),
        (REG_LED2_PA, LED2_CURRENT_VALUE),
        (REG_SLOT_CONFIG, SLOT_CONFIG_VALUE),
        (REG_MODE_CONFIG, MODE_MULTI_LED),
    ]
    assert slave.write_log == expected_writes, \
        f"init write sequence mismatch.\nexpected: {expected_writes}\ngot:      {slave.write_log}"

    # now push one real sample and confirm it's correctly read out
    test_value = 0b10_10101010_01010101  # arbitrary 18-bit pattern
    slave.push_sample(test_value)

    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.sample_valid.value == 1:
            break
    assert dut.sample_valid.value == 1, "sample_valid never pulsed"
    assert int(dut.raw_sample.value) == test_value, \
        f"expected raw_sample={test_value:#07x}, got {int(dut.raw_sample.value):#07x}"


@cocotb.test()
async def test_wrong_part_id_faults(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}

    async def bus_model():
        while True:
            await RisingEdge(dut.clk)
            try:
                master_drive = bool(dut.sda_drive_low.value)
            except ValueError:
                master_drive = False
            dut.sda_in.value = 0 if (master_drive or bus_state["slave_sda_drive_low"]) else 1

    cocotb.start_soon(bus_model())
    await reset_dut(dut)

    slave = MAX30102Model(dut, bus_state, part_id=0x99)  # wrong PART_ID
    cocotb.start_soon(slave.run())

    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.sensor_fault.value == 1:
            break
    assert dut.sensor_fault.value == 1, "sensor_fault must be set on a PART_ID mismatch"
    assert dut.init_done.value == 0, "init_done must never be set if PART_ID check failed"
    assert slave.write_log == [], "controller must not configure a device that failed the PART_ID check"


@cocotb.test()
async def test_reset_polling_actually_polls(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}

    async def bus_model():
        while True:
            await RisingEdge(dut.clk)
            try:
                master_drive = bool(dut.sda_drive_low.value)
            except ValueError:
                master_drive = False
            dut.sda_in.value = 0 if (master_drive or bus_state["slave_sda_drive_low"]) else 1

    cocotb.start_soon(bus_model())
    await reset_dut(dut)

    slave = MAX30102Model(dut, bus_state)
    slave.reset_countdown = 0
    cocotb.start_soon(slave.run())

    reads_of_mode_config = {"count": 0}
    orig_current_read = slave._current_read_byte

    def traced_read():
        if slave.reg_pointer == REG_MODE_CONFIG:
            reads_of_mode_config["count"] += 1
        return orig_current_read()
    slave._current_read_byte = traced_read

    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.init_done.value == 1:
            break
    assert dut.init_done.value == 1

    # MODE_CONFIG gets read: once during reset-polling (possibly several
    # times, since our model gives it a real multi-cycle delay), the
    # important thing is that it's read MORE than once, proving the
    # controller genuinely polls rather than reading exactly once and
    # assuming success.
    assert reads_of_mode_config["count"] >= 2, \
        f"expected the reset-polling loop to read MODE_CONFIG multiple times, saw {reads_of_mode_config['count']}"


@cocotb.test()
async def test_no_read_when_nothing_available(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}

    async def bus_model():
        while True:
            await RisingEdge(dut.clk)
            try:
                master_drive = bool(dut.sda_drive_low.value)
            except ValueError:
                master_drive = False
            dut.sda_in.value = 0 if (master_drive or bus_state["slave_sda_drive_low"]) else 1

    cocotb.start_soon(bus_model())
    await reset_dut(dut)

    slave = MAX30102Model(dut, bus_state)
    cocotb.start_soon(slave.run())

    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.init_done.value == 1:
            break
    assert dut.init_done.value == 1

    fifo_reads_before = sum(1 for (r, _) in [] )  # placeholder, real check below
    saw_sample_valid = False
    for _ in range(3000):
        await RisingEdge(dut.clk)
        if dut.sample_valid.value == 1:
            saw_sample_valid = True
    assert not saw_sample_valid, "sample_valid fired even though nothing was ever pushed into the FIFO"
    assert slave.fifo_queue == [], "no samples were ever pushed, queue should still be empty"


@cocotb.test()
async def test_multiple_samples_drain_correctly_with_wraparound(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}

    async def bus_model():
        while True:
            await RisingEdge(dut.clk)
            try:
                master_drive = bool(dut.sda_drive_low.value)
            except ValueError:
                master_drive = False
            dut.sda_in.value = 0 if (master_drive or bus_state["slave_sda_drive_low"]) else 1

    cocotb.start_soon(bus_model())
    await reset_dut(dut)

    slave = MAX30102Model(dut, bus_state)
    cocotb.start_soon(slave.run())

    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.init_done.value == 1:
            break
    assert dut.init_done.value == 1

    # drain 30 "dummy" samples through NORMAL operation first, so the
    # controller's own rd_ptr climbs up near the 32-entry wraparound
    # boundary exactly the way it would in real use (rather than
    # artificially/inconsistently pre-setting only the write pointer)
    for i in range(30):
        slave.push_sample(0x00001 + i)
    drained = 0
    for _ in range(400000):
        await RisingEdge(dut.clk)
        if dut.sample_valid.value == 1:
            drained += 1
        if drained == 30:
            break
    assert drained == 30, f"only drained {drained}/30 warm-up samples"

    # NOW push the real test values: FIFO_WR_PTR will genuinely wrap
    # (30 -> 31 -> 0 -> 1), exercising the mod-32 arithmetic for real
    values = [0x01234, 0x2FEDC, 0x3AAAA, 0x155555 & 0x3FFFF]
    for v in values:
        slave.push_sample(v)

    collected = []
    for _ in range(60000):
        await RisingEdge(dut.clk)
        if dut.sample_valid.value == 1:
            collected.append(int(dut.raw_sample.value))
        if len(collected) == len(values):
            break

    assert collected == values, f"expected {[hex(v) for v in values]}, got {[hex(v) for v in collected]}"


@cocotb.test()
async def test_nack_during_runtime_sets_fault(dut):
    """Simulate the sensor going unresponsive (NACKing) during normal
    runtime polling, and confirm sensor_fault is set."""
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}

    async def bus_model():
        while True:
            await RisingEdge(dut.clk)
            try:
                master_drive = bool(dut.sda_drive_low.value)
            except ValueError:
                master_drive = False
            dut.sda_in.value = 0 if (master_drive or bus_state["slave_sda_drive_low"]) else 1

    cocotb.start_soon(bus_model())
    await reset_dut(dut)

    slave = MAX30102Model(dut, bus_state)
    cocotb.start_soon(slave.run())

    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.init_done.value == 1:
            break
    assert dut.init_done.value == 1
    assert dut.sensor_fault.value == 0

    # now make the slave stop responding entirely (simulating a bus fault /
    # unplugged sensor) by killing its run loop
    slave._reset_edge_state()

    async def dead_slave():
        while True:
            await RisingEdge(dut.clk)
            bus_state["slave_sda_drive_low"] = False  # never acks anything

    cocotb.start_soon(dead_slave())

    for _ in range(20000):
        await RisingEdge(dut.clk)
        if dut.sensor_fault.value == 1:
            break
    assert dut.sensor_fault.value == 1, "sensor_fault must be set once the sensor stops acking"
