module i2c_byte_engine (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       i2c_tick,

    input  wire       cmd_valid,
    input  wire [1:0] cmd_type,
    input  wire [7:0] tx_byte,
    input  wire       read_ack_value,

    input  wire       sda_in,

    output wire       cmd_ready,
    output reg        cmd_done,
    output reg [7:0]  rx_byte,
    output reg        ack_received,
    output reg        i2c_error,

    output reg        sda_drive_low,
    output reg        scl_drive_low
);

    // ---- command type encoding ----
    localparam CMD_START      = 2'd0;
    localparam CMD_STOP       = 2'd1;
    localparam CMD_WRITE_BYTE = 2'd2;
    localparam CMD_READ_BYTE  = 2'd3;

    // ---- FSM states ----
    localparam S_IDLE               = 4'd0;
    localparam S_START_RELEASE_SDA  = 4'd1;
    localparam S_START_RELEASE_SCL  = 4'd2;
    localparam S_START_EDGE         = 4'd3;
    localparam S_START_SCL_LOW      = 4'd4;
    localparam S_BIT_LOW            = 4'd5;
    localparam S_BIT_SETUP          = 4'd6;
    localparam S_BIT_HIGH           = 4'd7;
    localparam S_BIT_SAMPLE         = 4'd8;
    localparam S_STOP_FORCE_SDA_LOW = 4'd9;
    localparam S_STOP_RAISE_SCL     = 4'd10;
    localparam S_STOP_EDGE          = 4'd11;
    localparam S_STOP_RELEASE_SCL   = 4'd12;

    reg [3:0] state;

    reg [7:0] tx_byte_latched;
    reg       read_ack_latched;
    reg       is_write;
    reg [3:0] bit_counter;   // 0-7 = data bits, 8 = ack/nack phase
    reg [7:0] rx_shift;

    wire currently_transmitting = is_write ? (bit_counter < 8) : (bit_counter == 8);
    wire tx_bit_value           = (bit_counter < 8) ? tx_byte_latched[7 - bit_counter] : read_ack_latched;

    assign cmd_ready = (state == S_IDLE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state            <= S_IDLE;
            cmd_done         <= 1'b0;
            rx_byte          <= 8'd0;
            ack_received     <= 1'b0;
            i2c_error        <= 1'b0;
            sda_drive_low    <= 1'b0;
            scl_drive_low    <= 1'b0;
            tx_byte_latched  <= 8'd0;
            read_ack_latched <= 1'b0;
            is_write         <= 1'b0;
            bit_counter      <= 4'd0;
            rx_shift         <= 8'd0;
        end
        else begin
            cmd_done  <= 1'b0;   // default: pulse only when explicitly completing a command

            if (i2c_tick) begin
                case (state)

                    S_IDLE: begin
                        if (cmd_valid) begin
                            case (cmd_type)
                                CMD_START: begin
                                    state <= S_START_RELEASE_SDA;
                                end
                                CMD_STOP: begin
                                    state <= S_STOP_FORCE_SDA_LOW;
                                end
                                CMD_WRITE_BYTE: begin
                                    tx_byte_latched <= tx_byte;
                                    is_write        <= 1'b1;
                                    bit_counter     <= 4'd0;
                                    state           <= S_BIT_LOW;
                                end
                                CMD_READ_BYTE: begin
                                    read_ack_latched <= read_ack_value;
                                    is_write         <= 1'b0;
                                    bit_counter      <= 4'd0;
                                    state            <= S_BIT_LOW;
                                end
                                default: begin
                                    state <= S_IDLE;
                                end
                            endcase
                        end
                    end

                    // ---- START (also serves as REPEATED START) ----
                    S_START_RELEASE_SDA: begin
                        sda_drive_low <= 1'b0;   // release SDA while SCL stays low
                        state <= S_START_RELEASE_SCL;
                    end

                    S_START_RELEASE_SCL: begin
                        scl_drive_low <= 1'b0;   // release SCL too: bus should now float idle-high
                        state <= S_START_EDGE;
                    end

                    S_START_EDGE: begin
                        if (!sda_in) begin
                            // SDA never actually floated high -- something else is holding the bus
                            i2c_error <= 1'b1;
                        end
                        sda_drive_low <= 1'b1;   // pull SDA low while SCL is high: the START edge
                        state <= S_START_SCL_LOW;
                    end

                    S_START_SCL_LOW: begin
                        scl_drive_low <= 1'b1;   // bring SCL low, ready to clock out the first bit
                        state    <= S_IDLE;
                        cmd_done <= 1'b1;
                    end

                    // ---- one bit cycle: shared by data bits AND the ack/nack bit ----
                    S_BIT_LOW: begin
                        scl_drive_low <= 1'b1;
                        if (currently_transmitting)
                            sda_drive_low <= tx_bit_value ? 1'b0 : 1'b1;
                        else
                            sda_drive_low <= 1'b0;  // release; the other side drives this bit
                        state <= S_BIT_SETUP;
                    end

                    S_BIT_SETUP: begin
                        state <= S_BIT_HIGH;
                    end

                    S_BIT_HIGH: begin
                        scl_drive_low <= 1'b0;
                        state <= S_BIT_SAMPLE;
                    end

                    S_BIT_SAMPLE: begin
                        if (!currently_transmitting) begin
                            if (bit_counter < 8)
                                rx_shift <= {rx_shift[6:0], sda_in};
                            else
                                ack_received <= ~sda_in;  // SDA low = ACK = success
                        end

                        if (bit_counter == 8) begin
                            if (!is_write)
                                rx_byte <= rx_shift;
                            scl_drive_low <= 1'b1;   // always park SCL low between commands
                            state    <= S_IDLE;
                            cmd_done <= 1'b1;
                        end else begin
                            bit_counter <= bit_counter + 1'b1;
                            state       <= S_BIT_LOW;
                        end
                    end

                    // ---- STOP ----
                    S_STOP_FORCE_SDA_LOW: begin
                        sda_drive_low <= 1'b1;
                        state <= S_STOP_RAISE_SCL;
                    end

                    S_STOP_RAISE_SCL: begin
                        scl_drive_low <= 1'b0;
                        state <= S_STOP_EDGE;
                    end

                    S_STOP_EDGE: begin
                        sda_drive_low <= 1'b0;   // release SDA while SCL is high: the STOP edge
                        state <= S_STOP_RELEASE_SCL;
                    end

                    S_STOP_RELEASE_SCL: begin
                        scl_drive_low <= 1'b0;
                        state    <= S_IDLE;
                        cmd_done <= 1'b1;
                    end

                    default: begin
                        state <= S_IDLE;
                    end

                endcase
            end
        end
    end

endmodule
