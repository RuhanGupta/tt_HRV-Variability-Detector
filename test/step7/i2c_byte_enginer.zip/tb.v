`timescale 1ns/1ps

module tb ();

    reg clk;
    reg rst_n;
    reg i2c_tick;

    reg cmd_valid;
    reg [1:0] cmd_type;
    reg [7:0] tx_byte;
    reg read_ack_value;
    reg sda_in;

    wire cmd_ready;
    wire cmd_done;
    wire [7:0] rx_byte;
    wire ack_received;
    wire i2c_error;
    wire sda_drive_low;
    wire scl_drive_low;

    initial begin
        $dumpfile("tb.fst");
        $dumpvars(0, tb);
    end

    i2c_byte_engine dut (
        .clk(clk),
        .rst_n(rst_n),
        .i2c_tick(i2c_tick),
        .cmd_valid(cmd_valid),
        .cmd_type(cmd_type),
        .tx_byte(tx_byte),
        .read_ack_value(read_ack_value),
        .sda_in(sda_in),
        .cmd_ready(cmd_ready),
        .cmd_done(cmd_done),
        .rx_byte(rx_byte),
        .ack_received(ack_received),
        .i2c_error(i2c_error),
        .sda_drive_low(sda_drive_low),
        .scl_drive_low(scl_drive_low)
    );

endmodule
