import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

CMD_START = 0
CMD_STOP = 1
CMD_WRITE_BYTE = 2
CMD_READ_BYTE = 3

TICK_PERIOD_CYCLES = 4  # small & arbitrary for fast simulation; the engine doesn't care


async def start_clock(dut):
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.cmd_valid.value = 0
    dut.cmd_type.value = 0
    dut.tx_byte.value = 0
    dut.read_ack_value.value = 0
    dut.sda_in.value = 1
    dut.i2c_tick.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


async def tick_source(dut):
    while True:
        for _ in range(TICK_PERIOD_CYCLES - 1):
            dut.i2c_tick.value = 0
            await RisingEdge(dut.clk)
        dut.i2c_tick.value = 1
        await RisingEdge(dut.clk)


async def bus_model(dut, bus_state):
    """The physical open-drain wire: low if EITHER the master or the
    (simulated) slave is pulling it low, high only if both release it."""
    while True:
        await RisingEdge(dut.clk)
        try:
            master_drive = bool(dut.sda_drive_low.value)
        except ValueError:
            master_drive = False  # still X before reset has run; treat as released
        slave_drive = bus_state["slave_sda_drive_low"]
        dut.sda_in.value = 0 if (master_drive or slave_drive) else 1


async def issue_command(dut, cmd_type, tx_byte=0, read_ack_value=0, timeout_cycles=2000):
    # wait until idle, in case a previous command is still finishing
    cycles = 0
    while dut.cmd_ready.value == 0:
        await RisingEdge(dut.clk)
        cycles += 1
        assert cycles < timeout_cycles, "engine never became ready"

    dut.cmd_type.value = cmd_type
    dut.tx_byte.value = tx_byte
    dut.read_ack_value.value = read_ack_value
    dut.cmd_valid.value = 1

    # hold cmd_valid until the command is actually accepted (cmd_ready drops)
    cycles = 0
    while dut.cmd_ready.value == 1:
        await RisingEdge(dut.clk)
        cycles += 1
        assert cycles < timeout_cycles, "command was never accepted"
    dut.cmd_valid.value = 0

    cycles = 0
    while dut.cmd_done.value == 0:
        await RisingEdge(dut.clk)
        cycles += 1
        assert cycles < timeout_cycles, "cmd_done never arrived"

    return {
        "rx_byte": int(dut.rx_byte.value),
        "ack_received": int(dut.ack_received.value),
        "i2c_error": int(dut.i2c_error.value),
    }


class I2CSlaveModel:
    """A behavioral I2C slave that reacts to actual SDA/SCL edges, exactly
    like a real device would, independent of the master's internal tick
    scheme. Detects START/STOP, captures address+R/W, ACKs only if
    addressed, accepts written bytes (ACKing each), and replies to reads
    from a configured byte queue, continuing only while the master keeps
    ACKing."""

    def __init__(self, dut, bus_state, address):
        self.dut = dut
        self.bus_state = bus_state
        self.address = address
        self.write_log = []
        self.read_queue = []
        self.transactions = []
        self._reset()

    def _reset(self):
        self.active = False
        self.phase = None
        self.addr_bits = []
        self.data_bits = []
        self.is_read = None
        self.addressed_to_us = False
        self.byte_index_in_read = 0
        self.bit_index = 0

    def sda_line(self):
        try:
            master = bool(self.dut.sda_drive_low.value)
        except ValueError:
            master = False
        return not (master or self.bus_state["slave_sda_drive_low"])

    def scl_line(self):
        try:
            return not bool(self.dut.scl_drive_low.value)
        except ValueError:
            return True

    async def run(self):
        prev_scl = self.scl_line()
        prev_sda = self.sda_line()
        while True:
            await RisingEdge(self.dut.clk)
            scl = self.scl_line()
            sda = self.sda_line()

            if scl and prev_scl and prev_sda and not sda:
                self._on_start()
            elif scl and prev_scl and (not prev_sda) and sda:
                self._on_stop()
            elif scl and not prev_scl:
                self._on_scl_rising(sda)
            elif (not scl) and prev_scl:
                self._on_scl_falling()

            prev_scl, prev_sda = scl, sda

    def _on_start(self):
        self.transactions.append({"write_log": [], "read_log": []})
        self.active = True
        self.phase = "ADDR"
        self.addr_bits = []
        self.bus_state["slave_sda_drive_low"] = False

    def _on_stop(self):
        self.active = False
        self.phase = None
        self.bus_state["slave_sda_drive_low"] = False

    def _on_scl_rising(self, sda):
        if not self.active:
            return
        if self.phase == "ADDR":
            self.addr_bits.append(1 if sda else 0)
            if len(self.addr_bits) == 8:
                addr_byte = 0
                for b in self.addr_bits:
                    addr_byte = (addr_byte << 1) | b
                self.is_read = bool(addr_byte & 1)
                self.addressed_to_us = ((addr_byte >> 1) == self.address)
                self.phase = "ADDR_ACK_PENDING"
        elif self.phase == "DATA_WRITE":
            self.data_bits.append(1 if sda else 0)
            if len(self.data_bits) == 8:
                byte_val = 0
                for b in self.data_bits:
                    byte_val = (byte_val << 1) | b
                self.write_log.append(byte_val)
                self.transactions[-1]["write_log"].append(byte_val)
                self.phase = "DATA_WRITE_ACK_PENDING"
        elif self.phase == "DATA_READ_SAMPLE_ACK":
            got_ack = not sda
            self.byte_index_in_read += 1
            if got_ack and self.byte_index_in_read < len(self.read_queue):
                self.phase = "DATA_READ_ARM"
            else:
                self.phase = "DONE_READING"

    def _on_scl_falling(self):
        if not self.active:
            return
        if self.phase == "ADDR_ACK_PENDING":
            self.bus_state["slave_sda_drive_low"] = self.addressed_to_us
            self.phase = "ADDR_ACK_DRIVING"
        elif self.phase == "ADDR_ACK_DRIVING":
            self.bus_state["slave_sda_drive_low"] = False
            if not self.addressed_to_us:
                self.phase = "IGNORED"
            elif self.is_read:
                self.byte_index_in_read = 0
                self.bit_index = 0
                self._drive_next_read_bit()
                self.phase = "DATA_READ"
            else:
                self.phase = "DATA_WRITE"
                self.data_bits = []
        elif self.phase == "DATA_WRITE_ACK_PENDING":
            self.bus_state["slave_sda_drive_low"] = True
            self.phase = "DATA_WRITE_ACK_DRIVING"
        elif self.phase == "DATA_WRITE_ACK_DRIVING":
            self.bus_state["slave_sda_drive_low"] = False
            self.data_bits = []
            self.phase = "DATA_WRITE"
        elif self.phase == "DATA_READ_ARM":
            self.bit_index = 0
            self._drive_next_read_bit()
            self.phase = "DATA_READ"
        elif self.phase == "DATA_READ":
            if self.bit_index < 8:
                self._drive_next_read_bit()
                if self.bit_index == 8:
                    self.phase = "DATA_READ_LAST_BIT_PENDING"
        elif self.phase == "DATA_READ_LAST_BIT_PENDING":
            # bit 7 has now actually been sampled by the master (its own
            # falling edge just occurred); only NOW release for the ack
            self.bus_state["slave_sda_drive_low"] = False
            self.phase = "DATA_READ_SAMPLE_ACK"
        elif self.phase in ("DONE_READING", "IGNORED"):
            self.bus_state["slave_sda_drive_low"] = False

    def _drive_next_read_bit(self):
        byte_val = self.read_queue[self.byte_index_in_read]
        bit = (byte_val >> (7 - self.bit_index)) & 1
        self.bus_state["slave_sda_drive_low"] = (bit == 0)
        self.bit_index += 1
        if self.bit_index == 8:
            self.transactions[-1]["read_log"].append(byte_val)




@cocotb.test()
async def test_start_sequence_scripted(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    assert dut.sda_drive_low.value == 0
    assert dut.scl_drive_low.value == 0

    result = await issue_command(dut, CMD_START)
    assert result["i2c_error"] == 0, "START on a genuinely free bus must not report an error"
    # after START: SDA driven low (mid start), SCL driven low (ready for first bit)
    assert dut.sda_drive_low.value == 1
    assert dut.scl_drive_low.value == 1


@cocotb.test()
async def test_stop_sequence_scripted(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    await issue_command(dut, CMD_START)
    await issue_command(dut, CMD_STOP)
    # after STOP, bus must be fully released (idle)
    assert dut.sda_drive_low.value == 0
    assert dut.scl_drive_low.value == 0


@cocotb.test()
async def test_write_byte_scripted_ack(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)
    await issue_command(dut, CMD_START)

    # drive an ACK (pull SDA low) for the whole WRITE_BYTE command's duration;
    # only the ack-phase bit actually matters, holding it throughout is harmless
    bus_state["slave_sda_drive_low"] = True
    result = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=0xA5)
    bus_state["slave_sda_drive_low"] = False

    assert result["ack_received"] == 1, "expected ACK to be recognized"
    assert result["i2c_error"] == 0


@cocotb.test()
async def test_write_byte_scripted_nack(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)
    await issue_command(dut, CMD_START)

    # never drive the bus low: slave "doesn't" ACK, line floats high
    result = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=0xA5)

    assert result["ack_received"] == 0, "expected NACK (no ack) to be recognized"
    assert result["i2c_error"] == 0, "a plain NACK must NOT be reported as i2c_error"


@cocotb.test()
async def test_write_byte_bit_order_and_timing(dut):
    """Watch sda_drive_low directly during a WRITE_BYTE and confirm the 8
    bits appear MSB-first, and SDA only ever changes while SCL is low."""
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": True}  # ACK so the command completes cleanly
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)
    await issue_command(dut, CMD_START)

    test_byte = 0b10110010  # deliberately not symmetric, so ordering mistakes show up

    observed_bits = []
    prev_scl = int(dut.scl_drive_low.value)
    prev_sda = int(dut.sda_drive_low.value)
    sda_changed_while_scl_high = False

    async def watcher():
        nonlocal prev_scl, prev_sda, sda_changed_while_scl_high
        while True:
            await RisingEdge(dut.clk)
            scl = int(dut.scl_drive_low.value)
            sda = int(dut.sda_drive_low.value)
            if sda != prev_sda and prev_scl == 0 and scl == 0:
                # SDA changed while SCL was (and stayed) released/high -- only
                # legal during START/STOP, not during ordinary bit transfer
                sda_changed_while_scl_high = True
            if scl == 1 and prev_scl == 0:
                # SCL just went low->... wait: scl_drive_low=1 means driven LOW.
                pass
            if prev_scl == 1 and scl == 0:
                # SCL transitioning from driven-low to released (rising edge of
                # the actual line): this is the sample point, capture SDA now.
                # sda_drive_low=1 means the line is electrically LOW (bit 0),
                # so the logical bit value is the inverse of the drive flag.
                observed_bits.append(1 - sda)
            prev_scl, prev_sda = scl, sda

    watcher_task = cocotb.start_soon(watcher())

    dut.cmd_type.value = CMD_WRITE_BYTE
    dut.tx_byte.value = test_byte
    dut.cmd_valid.value = 1
    while dut.cmd_ready.value == 1:
        await RisingEdge(dut.clk)
    dut.cmd_valid.value = 0
    while dut.cmd_done.value == 0:
        await RisingEdge(dut.clk)

    watcher_task.kill()

    # first 8 captured bits should be the byte, MSB first
    expected_bits = [(test_byte >> (7 - i)) & 1 for i in range(8)]
    assert observed_bits[:8] == expected_bits, \
        f"expected MSB-first bits {expected_bits}, observed {observed_bits[:8]}"


@cocotb.test()
async def test_read_byte_scripted_data(dut):
    """Drive a known byte onto sda_in at the right moments and confirm
    rx_byte assembles it correctly, MSB first."""
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)
    await issue_command(dut, CMD_START)

    test_byte = 0b01101101
    bits = [(test_byte >> (7 - i)) & 1 for i in range(8)]

    async def slave_driver():
        idx = 0
        prev_scl = int(dut.scl_drive_low.value)
        while idx < 8:
            await RisingEdge(dut.clk)
            scl = int(dut.scl_drive_low.value)
            if prev_scl == 1 and scl == 0:
                # SCL about to be released for this bit's high phase: set up
                # the bit we want the master to sample
                bus_state["slave_sda_drive_low"] = (bits[idx] == 0)
                idx += 1
            prev_scl = scl

    driver_task = cocotb.start_soon(slave_driver())
    result = await issue_command(dut, CMD_READ_BYTE, read_ack_value=1)  # NACK, single byte read
    driver_task.kill()
    bus_state["slave_sda_drive_low"] = False

    assert result["rx_byte"] == test_byte, \
        f"expected rx_byte={test_byte:#010b}, got {result['rx_byte']:#010b}"


@cocotb.test()
async def test_read_byte_master_drives_ack_and_nack(dut):
    """Confirm the master itself pulls SDA low for ACK (read_ack_value=0)
    and releases it for NACK (read_ack_value=1) during its own ack bit."""
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)
    await issue_command(dut, CMD_START)

    for ack_value, expect_drive_low in [(0, True), (1, False)]:
        observed_drive_during_ack = []

        async def watcher():
            bit_count = 0
            prev_scl = int(dut.scl_drive_low.value)
            while bit_count < 9:
                await RisingEdge(dut.clk)
                scl = int(dut.scl_drive_low.value)
                if prev_scl == 1 and scl == 0:
                    bit_count += 1
                    if bit_count == 9:
                        observed_drive_during_ack.append(int(dut.sda_drive_low.value))
                prev_scl = scl

        watcher_task = cocotb.start_soon(watcher())
        await issue_command(dut, CMD_READ_BYTE, read_ack_value=ack_value)
        watcher_task.kill()

        assert len(observed_drive_during_ack) == 1
        actual_drive_low = bool(observed_drive_during_ack[0])
        assert actual_drive_low == expect_drive_low, \
            f"read_ack_value={ack_value}: expected sda_drive_low={expect_drive_low} " \
            f"during the master's own ack bit, got {actual_drive_low}"


@cocotb.test()
async def test_stuck_bus_reports_error(dut):
    """If SDA never actually floats high after being released (something
    else is holding the bus down), START must flag i2c_error."""
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": True}  # something else holding SDA low, always
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    result = await issue_command(dut, CMD_START)
    assert result["i2c_error"] == 1, "expected i2c_error when the bus never actually freed"


@cocotb.test()
async def test_reset_clears_engine(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    assert dut.cmd_ready.value == 1
    assert dut.sda_drive_low.value == 0
    assert dut.scl_drive_low.value == 0
    assert dut.i2c_error.value == 0

# ============================================================
# TIER 2: behavioral I2C slave model, realistic protocol tests
# ============================================================

SLAVE_ADDRESS = 0x57  # arbitrary 7-bit address, matches MAX30102's real address for flavor


@cocotb.test()
async def test_behavioral_write_to_correct_address(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    slave = I2CSlaveModel(dut, bus_state, SLAVE_ADDRESS)
    cocotb.start_soon(slave.run())

    await issue_command(dut, CMD_START)
    r1 = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=(SLAVE_ADDRESS << 1) | 0)  # write
    assert r1["ack_received"] == 1, "slave should ACK its own address"

    r2 = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=0x42)
    assert r2["ack_received"] == 1, "slave should ACK a data byte"

    await issue_command(dut, CMD_STOP)

    assert slave.write_log == [0x42], f"expected slave to record [0x42], got {slave.write_log}"


@cocotb.test()
async def test_behavioral_write_register_then_repeated_start_read(dut):
    """The exact MAX30102 pattern: write the register address, repeated
    START, then read the data back."""
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    slave = I2CSlaveModel(dut, bus_state, SLAVE_ADDRESS)
    slave.read_queue = [0x99]
    cocotb.start_soon(slave.run())

    await issue_command(dut, CMD_START)
    r1 = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=(SLAVE_ADDRESS << 1) | 0)
    assert r1["ack_received"] == 1

    r2 = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=0x0A)  # "register address"
    assert r2["ack_received"] == 1

    await issue_command(dut, CMD_START)  # repeated START
    r3 = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=(SLAVE_ADDRESS << 1) | 1)  # read
    assert r3["ack_received"] == 1, "slave should ACK its address on the repeated START too"

    r4 = await issue_command(dut, CMD_READ_BYTE, read_ack_value=1)  # single byte, NACK
    await issue_command(dut, CMD_STOP)

    assert r4["rx_byte"] == 0x99, f"expected to read back 0x99, got {r4['rx_byte']:#04x}"
    assert slave.write_log == [0x0A]


@cocotb.test()
async def test_behavioral_multibyte_read_with_ack_and_final_nack(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    slave = I2CSlaveModel(dut, bus_state, SLAVE_ADDRESS)
    slave.read_queue = [0x11, 0x22, 0x33]
    cocotb.start_soon(slave.run())

    await issue_command(dut, CMD_START)
    await issue_command(dut, CMD_WRITE_BYTE, tx_byte=(SLAVE_ADDRESS << 1) | 1)  # straight into a read

    got = []
    for i in range(3):
        is_last = (i == 2)
        r = await issue_command(dut, CMD_READ_BYTE, read_ack_value=1 if is_last else 0)
        got.append(r["rx_byte"])
    await issue_command(dut, CMD_STOP)

    assert got == [0x11, 0x22, 0x33], f"expected [0x11,0x22,0x33], got {[hex(g) for g in got]}"


@cocotb.test()
async def test_behavioral_wrong_address_nacks(dut):
    await start_clock(dut)
    bus_state = {"slave_sda_drive_low": False}
    cocotb.start_soon(bus_model(dut, bus_state))
    cocotb.start_soon(tick_source(dut))
    await reset_dut(dut)

    slave = I2CSlaveModel(dut, bus_state, SLAVE_ADDRESS)
    cocotb.start_soon(slave.run())

    wrong_address = SLAVE_ADDRESS ^ 0x01  # differs from the slave's configured address

    await issue_command(dut, CMD_START)
    r1 = await issue_command(dut, CMD_WRITE_BYTE, tx_byte=(wrong_address << 1) | 0)
    assert r1["ack_received"] == 0, "slave must NOT ack an address that isn't its own"
    assert r1["i2c_error"] == 0, "a wrong-address NACK is normal protocol, not an i2c_error"

    await issue_command(dut, CMD_STOP)
    assert slave.write_log == [], "nothing should have been written to a slave that never acked"
