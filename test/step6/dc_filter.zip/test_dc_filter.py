"""
cocotb testbench for dc_filter.v

Checks the RTL cycle-by-cycle against a Python golden model implementing the
same Q18.6 fixed-point IIR DC tracker described in
ASIC_Fatigue_Specification_v1_1.md section 9.5 (FILTER_SHIFT=7, DC_FRAC_BITS=6).
"""

import math
import random

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ReadWrite

# ---- Fixed-point constants, must match the RTL exactly ----
FILTER_SHIFT = 7
DC_FRAC_BITS = 6
RAW_WIDTH = 18
DC_WIDTH = 24
AC_WIDTH = 19

RAW_MAX = (1 << RAW_WIDTH) - 1
DC_MASK = (1 << DC_WIDTH) - 1


def to_signed(value, width):
    """Reinterpret an unsigned Python int as a two's-complement signed value."""
    value &= (1 << width) - 1
    if value & (1 << (width - 1)):
        value -= (1 << width)
    return value


class DCFilterModel:
    """Golden reference: one step() call per clock cycle, bit-exact companion to the RTL."""

    def __init__(self):
        self.dc_estimate = 0          # unsigned Q18.6, 24-bit
        self.first_sample_seen = False

    def step(self, sample_valid: int, raw_sample: int):
        """
        Advance exactly one clock cycle. Returns (ac_sample, filter_valid)
        exactly as the RTL will present them right after this same clock edge.
        """
        if not sample_valid:
            return None, False

        if not self.first_sample_seen:
            self.dc_estimate = (raw_sample << DC_FRAC_BITS) & DC_MASK
            self.first_sample_seen = True
            return None, False  # seed cycle: no meaningful ac_sample yet

        old_dc = self.dc_estimate
        raw_extended = raw_sample << DC_FRAC_BITS
        error = raw_extended - old_dc            # signed, arbitrary precision in Python
        delta = error >> FILTER_SHIFT             # floors toward -inf, matches Verilog >>>
        self.dc_estimate = (old_dc + delta) & DC_MASK

        ac_sample = raw_sample - (old_dc >> DC_FRAC_BITS)
        ac_sample = to_signed(ac_sample, AC_WIDTH)
        return ac_sample, True


async def start_clock(dut, period_ns=10):
    cocotb.start_soon(Clock(dut.clk, period_ns, units="ns").start())


async def step_clock(dut):
    """Advance exactly one clock edge, then settle past the NBA-update region
    so registered outputs read back as their new (post-edge) values, while
    remaining able to drive new inputs immediately afterward (ReadWrite phase)."""
    await RisingEdge(dut.clk)
    await ReadWrite()


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.sample_valid.value = 0
    dut.raw_sample.value = 0
    await step_clock(dut)
    await step_clock(dut)
    dut.rst_n.value = 1
    await step_clock(dut)


async def run_sequence(dut, model, sequence, test_name):
    """
    sequence: list of (sample_valid, raw_sample_or_None) pairs, one per clock cycle.
    Drives each input, advances one clock, then checks the DUT's outputs
    against the golden model for that same cycle.
    """
    for cycle, (sv, rs) in enumerate(sequence):
        rs = 0 if rs is None else rs
        dut.sample_valid.value = sv
        dut.raw_sample.value = rs

        exp_ac, exp_valid = model.step(sv, rs)

        await step_clock(dut)

        actual_valid = bool(dut.filter_valid.value)
        assert actual_valid == exp_valid, (
            f"[{test_name}] cycle {cycle}: filter_valid mismatch - "
            f"expected {exp_valid}, got {actual_valid} "
            f"(sample_valid={sv}, raw_sample={rs})"
        )

        if exp_valid:
            actual_ac = to_signed(int(dut.ac_sample.value), AC_WIDTH)
            assert actual_ac == exp_ac, (
                f"[{test_name}] cycle {cycle}: ac_sample mismatch - "
                f"expected {exp_ac}, got {actual_ac} "
                f"(sample_valid={sv}, raw_sample={rs})"
            )


@cocotb.test()
async def test_constant_value(dut):
    """Test 1: constant raw value. dc_estimate should converge, ac_sample -> ~0."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    const_val = 50000
    sequence = [(1, const_val)] * 400
    await run_sequence(dut, model, sequence, "constant_value")

    final_dc_int = int(dut.dc_estimate.value) >> DC_FRAC_BITS
    assert abs(final_dc_int - const_val) <= 1, (
        f"dc_estimate did not converge: expected ~{const_val}, got {final_dc_int}"
    )


@cocotb.test()
async def test_step_change(dut):
    """Test 2: step change in baseline, confirms exact time-constant match with the model."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    sequence = [(1, 50000)] * 300 + [(1, 90000)] * 500
    await run_sequence(dut, model, sequence, "step_change")


@cocotb.test()
async def test_ramp(dut):
    """Test 3: slow ramp, confirms the tracker follows without diverging from the model."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    sequence = [(1, min(RAW_MAX, 20000 + i * 20)) for i in range(600)]
    await run_sequence(dut, model, sequence, "ramp")


@cocotb.test()
async def test_sinusoid_on_dc(dut):
    """Test 4: sinusoid riding on a DC offset, confirms AC content survives filtering."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    dc_level = 60000
    amplitude = 3000
    sequence = []
    for i in range(800):
        val = dc_level + int(amplitude * math.sin(2 * math.pi * i / 100))
        sequence.append((1, val))
    await run_sequence(dut, model, sequence, "sinusoid_on_dc")


@cocotb.test()
async def test_drift_plus_pulse(dut):
    """Test 5: slow drift combined with a pulse waveform, the realistic combined case."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    sequence = []
    for i in range(1000):
        drift = 40000 + i * 5
        pulse = int(2000 * math.sin(2 * math.pi * i / 80)) if (i // 80) % 2 == 0 else 0
        val = max(0, min(RAW_MAX, drift + pulse))
        sequence.append((1, val))
    await run_sequence(dut, model, sequence, "drift_plus_pulse")


@cocotb.test()
async def test_extremes(dut):
    """Test 6: max and min 18-bit ADC values, confirms no overflow/wraparound at the edges."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    sequence = [(1, RAW_MAX)] * 300 + [(1, 0)] * 300
    await run_sequence(dut, model, sequence, "extremes_max_then_min")


@cocotb.test()
async def test_first_sample_suppression(dut):
    """Test 7: filter_valid must stay low on the very first valid sample after reset,
    even though dc_estimate is seeded that same cycle."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    dut.sample_valid.value = 1
    dut.raw_sample.value = 77000
    exp_ac, exp_valid = model.step(1, 77000)
    await step_clock(dut)

    assert exp_valid is False, "test bug: model should report no valid output on the seed cycle"
    actual_valid = bool(dut.filter_valid.value)
    assert actual_valid == False, (
        "filter_valid was asserted on the very first sample after reset; the design "
        "requires it to stay low on the seed cycle"
    )


@cocotb.test()
async def test_one_cycle_latency(dut):
    """Test 8: filter_valid/ac_sample must appear exactly one clock edge after the
    sample_valid that produced them, not zero and not two."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    dut.sample_valid.value = 1
    dut.raw_sample.value = 60000
    model.step(1, 60000)
    await step_clock(dut)

    dut.sample_valid.value = 1
    dut.raw_sample.value = 61000
    exp_ac, exp_valid = model.step(1, 61000)
    await step_clock(dut)
    assert bool(dut.filter_valid.value) == exp_valid
    assert to_signed(int(dut.ac_sample.value), AC_WIDTH) == exp_ac

    dut.sample_valid.value = 0
    await step_clock(dut)
    assert bool(dut.filter_valid.value) == False, (
        "filter_valid stayed high one cycle too long after sample_valid dropped"
    )


@cocotb.test()
async def test_idle_holds_state(dut):
    """Test 9: while sample_valid is low for many cycles, dc_estimate must not
    drift or change at all."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    seed_sequence = [(1, 55000)] * 50
    await run_sequence(dut, model, seed_sequence, "idle_seed")

    dc_before = int(dut.dc_estimate.value)

    idle_sequence = [(0, None)] * 200
    await run_sequence(dut, model, idle_sequence, "idle_hold")

    dc_after = int(dut.dc_estimate.value)
    assert dc_before == dc_after, (
        f"dc_estimate drifted while idle: before={dc_before}, after={dc_after}"
    )


@cocotb.test()
async def test_reset_mid_stream(dut):
    """Test 10: assert reset partway through real samples, confirm state clears,
    then confirm the module re-seeds cleanly from the next valid sample."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()

    warm_sequence = [(1, 70000)] * 100
    await run_sequence(dut, model, warm_sequence, "reset_mid_stream_warmup")

    dut.rst_n.value = 0
    dut.sample_valid.value = 0
    await step_clock(dut)
    assert int(dut.dc_estimate.value) == 0
    assert bool(dut.filter_valid.value) == False

    dut.rst_n.value = 1
    await step_clock(dut)

    model2 = DCFilterModel()
    post_reset_sequence = [(1, 40000)] * 100
    await run_sequence(dut, model2, post_reset_sequence, "reset_mid_stream_recovery")


@cocotb.test()
async def test_randomized_trace(dut):
    """Bonus: randomized sample stream with occasional idle gaps, broad regression check."""
    await start_clock(dut)
    await reset_dut(dut)
    model = DCFilterModel()
    random.seed(12345)

    sequence = []
    for _ in range(2000):
        if random.random() < 0.05:
            sequence.append((0, None))
        else:
            sequence.append((1, random.randint(0, RAW_MAX)))
    await run_sequence(dut, model, sequence, "randomized_trace")