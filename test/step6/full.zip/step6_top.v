// Chains dc_filter -> peak_detector for integration testing.
module step6_top (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        sample_valid,
    input  wire [17:0] raw_sample,
    output wire        peak_valid,
    output wire signed [18:0] ac_sample,
    output wire        filter_valid
);
    dc_filter dc (
        .clk(clk),
        .rst_n(rst_n),
        .sample_valid(sample_valid),
        .raw_sample(raw_sample),
        .ac_sample(ac_sample),
        .filter_valid(filter_valid)
    );

    peak_detector pd (
        .clk(clk),
        .rst_n(rst_n),
        .filter_valid(filter_valid),
        .ac_sample(ac_sample),
        .peak_valid(peak_valid)
    );
endmodule
