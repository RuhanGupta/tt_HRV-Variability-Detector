"""
Integration test: dc_filter -> peak_detector chained together (step6_top.v),
replayed against the real recorded IR trace from MAX30102_usage.csv
(the Session 1 5-phase capture: RESTING, LOOSE_CONTACT, MOTION, TENSE,
RELAXED_AFTER). Column layout confirmed by inspection: col0=sample index,
col1=timestamp_ms, col2=IR, col3=RED, col4=phase label. Only IR (col2) is
used, matching the finalized IR-only sensor strategy.
"""

import csv
import os

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ReadWrite

FILTER_SHIFT = 7
DC_FRAC_BITS = 6
ENVELOPE_DECAY_SHIFT = 6
THRESHOLD_SHIFT = 2
WARMUP_SAMPLES = 200
REFRACTORY_SAMPLES = 35
RAW_WIDTH = 18
DC_WIDTH = 24
AC_WIDTH = 19
DC_MASK = (1 << DC_WIDTH) - 1
SAMPLE_RATE_HZ = 100

CSV_PATH = os.path.join(os.path.dirname(__file__), "MAX30102_usage.csv")


def to_signed(value, width):
    value &= (1 << width) - 1
    if value & (1 << (width - 1)):
        value -= (1 << width)
    return value


def to_unsigned(value, width):
    return value & ((1 << width) - 1)


def load_phase(phase_name, min_ir=100000):
    """Load the IR column for one phase, skipping the leading segment before
    the finger is clearly making contact (IR still near the pre-contact
    floor). min_ir is the threshold used to detect 'finger is on'."""
    rows = []
    with open(CSV_PATH) as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) != 5 or row[4] != phase_name:
                continue
            try:
                ir = int(row[2])
            except ValueError:
                continue
            rows.append(ir)

    start = 0
    for i, ir in enumerate(rows):
        if ir >= min_ir:
            start = i
            break
    return rows[start:]


class Step6Model:
    """Golden model chaining the exact same fixed-point dc_filter + peak_detector
    behavior verified earlier, used here purely as an independent cross-check
    on real data (not the primary pass/fail — real physiological data is noisy,
    so the primary check is BPM falling in a plausible range)."""

    def __init__(self):
        self.dc_estimate = 0
        self.first_sample_seen = False

        self.envelope = 0
        self.threshold = 0
        self.candidate_peak = 0
        self.rising = False
        self.refractory_count = 0
        self.warmup_count = 0

    def step(self, raw_sample):
        # --- dc_filter stage ---
        if not self.first_sample_seen:
            self.dc_estimate = (raw_sample << DC_FRAC_BITS) & DC_MASK
            self.first_sample_seen = True
            return None, False  # no ac_sample yet, and therefore no peak this cycle

        old_dc = self.dc_estimate
        raw_extended = raw_sample << DC_FRAC_BITS
        error = raw_extended - old_dc
        delta = error >> FILTER_SHIFT
        self.dc_estimate = (old_dc + delta) & DC_MASK
        ac_sample = raw_sample - (old_dc >> DC_FRAC_BITS)
        ac_sample = to_signed(ac_sample, AC_WIDTH)

        # --- peak_detector stage ---
        sample = -ac_sample
        if sample > self.envelope:
            next_envelope = sample
        else:
            next_envelope = self.envelope - (self.envelope >> ENVELOPE_DECAY_SHIFT)
        next_threshold = self.envelope - (self.envelope >> THRESHOLD_SHIFT)

        peak_valid = False
        next_warmup = self.warmup_count
        next_refractory = self.refractory_count
        next_rising = self.rising
        next_candidate = self.candidate_peak

        if self.warmup_count < WARMUP_SAMPLES:
            next_warmup = self.warmup_count + 1
        elif self.refractory_count > 0:
            next_refractory = self.refractory_count - 1
        elif not self.rising and sample > self.threshold:
            next_rising = True
            next_candidate = sample
        elif self.rising and sample > self.candidate_peak:
            next_candidate = sample
        elif self.rising and sample <= self.candidate_peak:
            next_rising = False
            next_refractory = REFRACTORY_SAMPLES
            peak_valid = True

        self.envelope = next_envelope
        self.threshold = next_threshold
        self.warmup_count = next_warmup
        self.refractory_count = next_refractory
        self.rising = next_rising
        self.candidate_peak = next_candidate

        return ac_sample, peak_valid


async def start_clock(dut, period_ns=10):
    cocotb.start_soon(Clock(dut.clk, period_ns, units="ns").start())


async def step_clock(dut):
    await RisingEdge(dut.clk)
    await ReadWrite()


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.sample_valid.value = 0
    dut.raw_sample.value = 0
    await step_clock(dut)
    await step_clock(dut)
    dut.rst_n.value = 1
    await step_clock(dut)


def bpm_from_peak_cycles(peak_cycles):
    if len(peak_cycles) < 2:
        return None, []
    intervals = [b - a for a, b in zip(peak_cycles, peak_cycles[1:])]
    mean_interval = sum(intervals) / len(intervals)
    bpm = 60.0 * SAMPLE_RATE_HZ / mean_interval
    return bpm, intervals


async def replay_phase(dut, phase_name, expected_bpm, tolerance):
    model = Step6Model()
    samples = load_phase(phase_name)

    rtl_peak_cycles = []
    model_peak_cycles = []

    for cycle, raw in enumerate(samples):
        dut.sample_valid.value = 1
        dut.raw_sample.value = to_unsigned(raw, RAW_WIDTH)

        _, model_peak = model.step(raw)
        if model_peak:
            model_peak_cycles.append(cycle)

        await step_clock(dut)

        if bool(dut.peak_valid.value):
            rtl_peak_cycles.append(cycle)

    # dc_filter and peak_detector are two separately-registered stages wired
    # directly together: peak_detector's always block reads dc_filter's
    # ac_sample/filter_valid as they stood BEFORE this same edge (classic
    # register-to-register latency), so every RTL peak lands exactly one
    # cycle later than the same-cycle combined model predicts. This is a
    # constant pipeline delay, not a functional mismatch, and doesn't affect
    # measured intervals since it shifts every peak by the same amount.
    shifted_model_peaks = [c + 1 for c in model_peak_cycles]
    assert rtl_peak_cycles == shifted_model_peaks, (
        f"[{phase_name}] RTL and golden model disagree on peak positions "
        f"(beyond the expected constant +1 cycle pipeline latency).\n"
        f"RTL:            {rtl_peak_cycles}\n"
        f"Model (+1 cyc): {shifted_model_peaks}"
    )

    bpm, intervals = bpm_from_peak_cycles(rtl_peak_cycles)
    dut._log.info(
        f"[{phase_name}] {len(rtl_peak_cycles)} peaks over {len(samples)} samples, "
        f"BPM={bpm}, intervals(samples)={intervals}"
    )

    assert bpm is not None, f"[{phase_name}] fewer than 2 peaks detected, cannot compute BPM"
    assert abs(bpm - expected_bpm) <= tolerance, (
        f"[{phase_name}] BPM {bpm:.1f} outside expected {expected_bpm}+/-{tolerance}"
    )
    return bpm, rtl_peak_cycles


@cocotb.test()
async def test_resting_phase_bpm(dut):
    """RESTING (settled): cleanest data in the whole recording. Session 1's
    three independent methods agreed at 62.5-67.5 BPM; the Python fixed-point
    reference model (session 3) got 67.0 BPM on this exact segment. Wide
    tolerance since this is real physiological data, not synthetic."""
    await start_clock(dut)
    await reset_dut(dut)
    bpm, peaks = await replay_phase(dut, "RESTING", expected_bpm=67.0, tolerance=15.0)


@cocotb.test()
async def test_relaxed_after_phase_bpm(dut):
    """RELAXED_AFTER: session 1 dip-based estimate was 62.1 BPM (loosest
    agreement of the 3 methods, ~14 BPM spread), so a wider tolerance here."""
    await start_clock(dut)
    await reset_dut(dut)
    bpm, peaks = await replay_phase(dut, "RELAXED_AFTER", expected_bpm=62.1, tolerance=20.0)


@cocotb.test()
async def test_tense_phase_bpm(dut):
    """TENSE: session 1 dip-based estimate was 69.8 BPM."""
    await start_clock(dut)
    await reset_dut(dut)
    bpm, peaks = await replay_phase(dut, "TENSE", expected_bpm=69.8, tolerance=20.0)


@cocotb.test()
async def test_no_crash_on_disturbed_phases(dut):
    """MOTION and LOOSE_CONTACT are expected to be messy - no BPM assertion,
    just confirms the RTL runs to completion and stays bit-exact with the
    golden model even on noisy/disturbed data (no undefined states, no
    divergence from unexpected input patterns)."""
    await start_clock(dut)
    await reset_dut(dut)
    model = Step6Model()

    for phase in ("LOOSE_CONTACT", "MOTION"):
        samples = load_phase(phase, min_ir=50000)
        rtl_peaks = []
        model_peaks = []
        for cycle, raw in enumerate(samples):
            dut.sample_valid.value = 1
            dut.raw_sample.value = to_unsigned(raw, RAW_WIDTH)
            _, model_peak = model.step(raw)
            if model_peak:
                model_peaks.append(cycle)
            await step_clock(dut)
            if bool(dut.peak_valid.value):
                rtl_peaks.append(cycle)
        shifted_model_peaks = [c + 1 for c in model_peaks]
        assert rtl_peaks == shifted_model_peaks, f"[{phase}] RTL/model mismatch: {rtl_peaks} vs {shifted_model_peaks}"
        dut._log.info(f"[{phase}] ran {len(samples)} samples, {len(rtl_peaks)} peaks, no mismatch")
