"""
cocotb testbench for peak_detector.v

Golden model mirrors the RTL exactly as written: envelope decay via
ENVELOPE_DECAY_SHIFT=6, threshold = envelope - (envelope >> THRESHOLD_SHIFT=2),
WARMUP_SAMPLES=200, REFRACTORY_SAMPLES=35, peak declared when a rising
candidate stops exceeding its own running max (candidate_peak-based check).
"""

import random
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ReadWrite

ENVELOPE_DECAY_SHIFT = 6
THRESHOLD_SHIFT = 2
WARMUP_SAMPLES = 200
REFRACTORY_SAMPLES = 35
AC_WIDTH = 19


def to_signed(value, width):
    value &= (1 << width) - 1
    if value & (1 << (width - 1)):
        value -= (1 << width)
    return value


def to_unsigned(value, width):
    return value & ((1 << width) - 1)


class PeakDetectorModel:
    def __init__(self):
        self.envelope = 0
        self.threshold = 0          # registered, same one-cycle-behind timing as the RTL
        self.candidate_peak = 0
        self.rising = False
        self.refractory_count = 0
        self.warmup_count = 0

    def step(self, filter_valid: int, ac_sample: int):
        """
        Advance one clock cycle. Mirrors non-blocking-assignment semantics:
        every "next" value below is computed from state as it stood BEFORE
        this edge, and all state is committed together at the end, exactly
        like every `<=` in the RTL's always block reading pre-edge values.
        """
        if not filter_valid:
            return False

        sample = -ac_sample  # polarity invert, matches POLARITY_INVERT=True

        if sample > self.envelope:
            next_envelope = sample
        else:
            next_envelope = self.envelope - (self.envelope >> ENVELOPE_DECAY_SHIFT)

        next_threshold = self.envelope - (self.envelope >> THRESHOLD_SHIFT)

        next_warmup_count = self.warmup_count
        next_refractory_count = self.refractory_count
        next_rising = self.rising
        next_candidate_peak = self.candidate_peak
        peak_valid = False

        if self.warmup_count < WARMUP_SAMPLES:
            next_warmup_count = self.warmup_count + 1
        elif self.refractory_count > 0:
            next_refractory_count = self.refractory_count - 1
        elif not self.rising and sample > self.threshold:
            next_rising = True
            next_candidate_peak = sample
        elif self.rising and sample > self.candidate_peak:
            next_candidate_peak = sample
        elif self.rising and sample <= self.candidate_peak:
            next_rising = False
            next_refractory_count = REFRACTORY_SAMPLES
            peak_valid = True

        self.envelope = next_envelope
        self.threshold = next_threshold
        self.warmup_count = next_warmup_count
        self.refractory_count = next_refractory_count
        self.rising = next_rising
        self.candidate_peak = next_candidate_peak

        return peak_valid


async def start_clock(dut, period_ns=10):
    cocotb.start_soon(Clock(dut.clk, period_ns, units="ns").start())


async def step_clock(dut):
    await RisingEdge(dut.clk)
    await ReadWrite()


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.filter_valid.value = 0
    dut.ac_sample.value = 0
    await step_clock(dut)
    await step_clock(dut)
    dut.rst_n.value = 1
    await step_clock(dut)


async def run_sequence(dut, model, sequence, test_name, expected_peaks=None):
    """
    sequence: list of (filter_valid, ac_sample_or_None) pairs.
    expected_peaks: optional list of cycle indices where a peak MUST occur
    (checked at the end, in addition to the per-cycle model check).
    """
    actual_peak_cycles = []
    for cycle, (fv, ac) in enumerate(sequence):
        ac = 0 if ac is None else ac
        dut.filter_valid.value = fv
        dut.ac_sample.value = to_unsigned(ac, AC_WIDTH)

        exp_peak = model.step(fv, ac)

        await step_clock(dut)

        actual_peak = bool(dut.peak_valid.value)
        assert actual_peak == exp_peak, (
            f"[{test_name}] cycle {cycle}: peak_valid mismatch - "
            f"expected {exp_peak}, got {actual_peak} (ac_sample={ac})"
        )
        if actual_peak:
            actual_peak_cycles.append(cycle)

    if expected_peaks is not None:
        assert actual_peak_cycles == expected_peaks, (
            f"[{test_name}] peak positions mismatch - "
            f"expected {expected_peaks}, got {actual_peak_cycles}"
        )
    return actual_peak_cycles


def synthetic_pulses(period, num_pulses, dip_depth=-2000, pulse_width=6, baseline_len=None):
    """Build a periodic dip-shaped waveform: mostly ~0, with a short negative
    dip of `dip_depth` every `period` samples, `num_pulses` times."""
    if baseline_len is None:
        baseline_len = period
    values = []
    for _ in range(num_pulses):
        segment = [0] * (period - pulse_width)
        # a triangular dip: down, bottom, up
        half = pulse_width // 2
        for i in range(half):
            segment.append(int(dip_depth * (i + 1) / half))
        for i in range(pulse_width - half):
            segment.append(int(dip_depth * (pulse_width - half - i) / (pulse_width - half)))
        values.extend(segment)
    return values


@cocotb.test()
async def test_clean_periodic_peaks(dut):
    """Test 1: clean synthetic dips at a known period, confirm exact peak count/spacing."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()

    period = 100
    values = synthetic_pulses(period, num_pulses=10)
    sequence = [(1, v) for v in values]

    peaks = await run_sequence(dut, model, sequence, "clean_periodic_peaks")
    assert len(peaks) >= 8, f"expected close to 10 peaks, got {len(peaks)}: {peaks}"
    if len(peaks) >= 2:
        spacings = [b - a for a, b in zip(peaks, peaks[1:])]
        for s in spacings:
            assert abs(s - period) <= 2, f"peak spacing {s} far from expected period {period}"


@cocotb.test()
async def test_varying_amplitude(dut):
    """Test 2: amplitude changes over time, confirms adaptive envelope keeps triggering."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()

    values = []
    for amp in (-1000, -3000, -1500, -4000):
        values.extend(synthetic_pulses(100, num_pulses=5, dip_depth=amp))
    sequence = [(1, v) for v in values]

    peaks = await run_sequence(dut, model, sequence, "varying_amplitude")
    assert len(peaks) >= 15, f"expected close to 20 peaks across amplitude changes, got {len(peaks)}"


@cocotb.test()
async def test_refractory_suppresses_notch(dut):
    """Test 3: a secondary dip right after a real peak, inside the refractory
    window, must be suppressed."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()

    values = synthetic_pulses(100, num_pulses=3, dip_depth=-3000)
    # insert a small secondary notch 15 samples after each real dip (well
    # inside the 35-sample refractory window)
    notch_positions = []
    for i in range(3):
        pos = 100 * i + 50 + 15
        notch_positions.append(pos)
    for pos in notch_positions:
        if pos < len(values):
            values[pos] = -800  # smaller secondary bump

    sequence = [(1, v) for v in values]
    peaks = await run_sequence(dut, model, sequence, "refractory_suppresses_notch")
    # golden model itself enforces refractory suppression; this test's real
    # job is confirming the RTL matches the model cycle-for-cycle (already
    # checked inside run_sequence), i.e. it does NOT independently declare
    # a peak at the notch that the model didn't also declare.


@cocotb.test()
async def test_noise_below_threshold(dut):
    """Test 4: after envelope is established by a real signal, small noise
    that stays below the resulting threshold should not trigger."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()
    random.seed(42)

    # establish a realistic envelope first (noise alone never builds one)
    warmup_values = synthetic_pulses(100, num_pulses=5, dip_depth=-3000)
    await run_sequence(dut, model, [(1, v) for v in warmup_values], "noise_below_threshold_warmup")

    # now inject small noise, well under the established envelope/threshold
    sequence = [(1, random.randint(-50, 50)) for _ in range(300)]
    peaks = await run_sequence(dut, model, sequence, "noise_below_threshold")
    assert len(peaks) == 0, f"expected zero peaks from small noise once envelope is established, got {len(peaks)}: {peaks}"


@cocotb.test()
async def test_inverted_waveform_polarity(dut):
    """Test 5: if the waveform were NOT dip-shaped (bump-shaped instead),
    the detector should NOT fire, confirming polarity inversion is real
    (this is the exact bug found in the submitted code)."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()

    # positive-going bumps (wrong polarity for this detector)
    values = synthetic_pulses(100, num_pulses=5, dip_depth=3000)
    sequence = [(1, v) for v in values]
    peaks = await run_sequence(dut, model, sequence, "inverted_waveform_polarity")
    assert len(peaks) == 0, (
        f"positive-going bumps should not trigger a dip-polarity detector, got {len(peaks)}"
    )


@cocotb.test()
async def test_peaks_inside_refractory_merged(dut):
    """Test 6: two true dips placed closer together than the refractory
    window must be counted as one."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()

    values = [0] * 350
    for center in (250, 250 + 20):  # only 20 samples apart, refractory=35
        for i in range(-3, 4):
            idx = center + i
            if 0 <= idx < len(values):
                values[idx] = -3000 + abs(i) * 400
    sequence = [(1, v) for v in values]
    peaks = await run_sequence(dut, model, sequence, "peaks_inside_refractory_merged")
    assert len(peaks) == 1, f"expected exactly one merged peak, got {len(peaks)}: {peaks}"


@cocotb.test()
async def test_peaks_outside_refractory_both_counted(dut):
    """Test 7: two true dips placed just outside the refractory window must
    both be counted."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()

    values = [0] * 350
    for center in (250, 250 + 60):  # 60 samples apart, well past refractory=35
        for i in range(-3, 4):
            idx = center + i
            if 0 <= idx < len(values):
                values[idx] = -3000 + abs(i) * 400
    sequence = [(1, v) for v in values]
    peaks = await run_sequence(dut, model, sequence, "peaks_outside_refractory_both_counted")
    assert len(peaks) == 2, f"expected exactly two separate peaks, got {len(peaks)}: {peaks}"


@cocotb.test()
async def test_no_local_maximum_no_peak(dut):
    """Test 8: signal crosses threshold but keeps climbing past the end of
    the window without ever turning over -> no peak should fire mid-climb."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()

    values = [0] * 250 + [int(-50 * i) for i in range(1, 40)]  # monotonic dip, never recovers
    sequence = [(1, v) for v in values]
    peaks = await run_sequence(dut, model, sequence, "no_local_maximum_no_peak")
    assert len(peaks) == 0, f"expected no peak while still monotonically dipping, got {peaks}"


@cocotb.test()
async def test_randomized_trace(dut):
    """Bonus: randomized realistic-ish trace with idle gaps, broad regression check."""
    await start_clock(dut)
    await reset_dut(dut)
    model = PeakDetectorModel()
    random.seed(99)

    values = synthetic_pulses(90, num_pulses=15, dip_depth=-2500)
    sequence = []
    for v in values:
        if random.random() < 0.03:
            sequence.append((0, None))
        sequence.append((1, v + random.randint(-30, 30)))

    await run_sequence(dut, model, sequence, "randomized_trace")
