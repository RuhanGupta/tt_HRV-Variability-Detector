import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge


async def start_clock(dut):
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.sample_valid.value = 0
    dut.peak_valid.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


async def heartbeat(dut, target_samples):
    for s in range(target_samples):
        dut.sample_valid.value = 1
        dut.peak_valid.value = 1 if s == target_samples - 1 else 0
        await RisingEdge(dut.clk)
    dut.sample_valid.value = 0
    dut.peak_valid.value = 0
    await RisingEdge(dut.clk)


@cocotb.test()
async def test_full_calibrate_alert_recover(dut):
    """Drives stimulus ADAPTIVELY based on the DUT's own state, rather than
    a pre-committed fixed-length sequence, so the measured deltas between
    events are exact and not polluted by extra/insufficient heartbeats
    before a phase transition."""
    await start_clock(dut)
    await reset_dut(dut)

    jitter = [98, 102, 100, 104, 99, 103, 101, 97]
    heartbeat_num = 0
    alert_before_baseline = False

    async def drive_and_count(target):
        nonlocal heartbeat_num
        await heartbeat(dut, target)
        heartbeat_num += 1
        if dut.alert_out.value == 1 and dut.main_baseline_valid.value == 0:
            nonlocal alert_before_baseline
            alert_before_baseline = True

    # ---- Phase 1: jitter until baseline locks in ----
    MAX_CALIB_HEARTBEATS = 300
    j = 0
    while dut.main_baseline_valid.value == 0:
        assert heartbeat_num < MAX_CALIB_HEARTBEATS, \
            f"baseline never locked in after {MAX_CALIB_HEARTBEATS} heartbeats"
        await drive_and_count(jitter[j % 8])
        j += 1
    hb_baseline = heartbeat_num
    baseline_value = int(dut.main_baseline_variability.value)
    assert baseline_value == 3, f"expected baseline=3 for this jitter pattern, got {baseline_value}"
    print(f"\nPhase 1 done: baseline locked at heartbeat #{hb_baseline}, value={baseline_value}")

    # ---- Phase 2: flat (constant interval) until alert fires ----
    MAX_FLAT_HEARTBEATS = 100
    flat_start = heartbeat_num
    while dut.alert_out.value == 0:
        assert heartbeat_num - flat_start < MAX_FLAT_HEARTBEATS, \
            f"alert never fired after {MAX_FLAT_HEARTBEATS} flat heartbeats"
        await drive_and_count(100)
        # baseline must never move once locked
        assert int(dut.main_baseline_variability.value) == baseline_value, \
            "baseline drifted after being locked in"
        assert dut.main_baseline_valid.value == 1
    hb_alert = heartbeat_num
    delta_to_alert = hb_alert - hb_baseline
    print(f"Phase 2 done: alert asserted at heartbeat #{hb_alert} ({delta_to_alert} heartbeats after baseline lock)")

    # ---- Phase 3: back to jitter until alert clears ----
    MAX_RECOVER_HEARTBEATS = 100
    recover_start = heartbeat_num
    j = 0
    while dut.alert_out.value == 1:
        assert heartbeat_num - recover_start < MAX_RECOVER_HEARTBEATS, \
            f"alert never recovered after {MAX_RECOVER_HEARTBEATS} jittery heartbeats"
        await drive_and_count(jitter[j % 8])
        j += 1
    hb_recover = heartbeat_num
    delta_to_recover = hb_recover - hb_alert
    print(f"Phase 3 done: alert recovered at heartbeat #{hb_recover} ({delta_to_recover} heartbeats after alert)")

    # a little extra jitter afterward, to confirm it STAYS recovered, doesn't flicker
    for j2 in range(16):
        await drive_and_count(jitter[j2 % 8])
        assert dut.alert_out.value == 0, "alert flickered back on after recovering"

    # ---- final invariant checks ----
    assert not alert_before_baseline, \
        "alert_out was observed high while baseline_valid was still low -- must never happen"
    assert delta_to_alert == 32, \
        f"expected exactly 32 heartbeats (4 blocks x 8) from baseline lock to alert, got {delta_to_alert}"
    assert delta_to_recover == 16, \
        f"expected exactly 16 heartbeats (2 blocks x 8) from alert to recovery, got {delta_to_recover}"

    print(f"\nALL INVARIANTS HELD:")
    print(f"  - no alert before baseline existed")
    print(f"  - baseline locked exactly once at #{hb_baseline} (value={baseline_value}) and never drifted")
    print(f"  - alert required exactly 4 consecutive low blocks ({delta_to_alert} heartbeats) to fire")
    print(f"  - recovery took exactly 2 good blocks ({delta_to_recover} heartbeats)")
    print(f"  - alert stayed off through 16 further heartbeats of normal jitter (no flicker)")


@cocotb.test()
async def test_reset_mid_alert_recovers_cleanly(dut):
    """Reset the whole chain while an alert is actively asserted, and
    confirm everything clears and a fresh calibration works correctly
    afterward -- the chip must be able to recover from ANY state, not
    just from idle."""
    await start_clock(dut)
    await reset_dut(dut)

    jitter = [98, 102, 100, 104, 99, 103, 101, 97]
    heartbeat_num = 0

    async def drive(target):
        nonlocal heartbeat_num
        await heartbeat(dut, target)
        heartbeat_num += 1

    # get to a locked baseline
    j = 0
    while dut.main_baseline_valid.value == 0:
        await drive(jitter[j % 8])
        j += 1
    assert int(dut.main_baseline_variability.value) == 3

    # push it into an alert
    while dut.alert_out.value == 0:
        await drive(100)
    assert dut.alert_out.value == 1
    assert dut.main_baseline_valid.value == 1

    # reset RIGHT HERE, mid-alert, mid-everything
    await reset_dut(dut)
    assert dut.alert_out.value == 0, "alert_out must clear on reset"
    assert dut.main_baseline_valid.value == 0, "baseline_valid must clear on reset"
    assert int(dut.main_baseline_variability.value) == 0, "baseline_variability must clear on reset"

    # confirm a FRESH calibration works correctly after this reset
    heartbeat_num = 0
    j = 0
    MAX = 300
    while dut.main_baseline_valid.value == 0:
        assert heartbeat_num < MAX, "fresh post-reset calibration never completed"
        await drive(jitter[j % 8])
        j += 1
    assert int(dut.main_baseline_variability.value) == 3, \
        "fresh calibration after mid-alert reset produced a different baseline than expected"

    print(f"\nReset mid-alert recovered cleanly: baseline/alert cleared immediately, "
          f"and a fresh calibration afterward correctly reached baseline=3 again "
          f"at heartbeat #{heartbeat_num}.")
