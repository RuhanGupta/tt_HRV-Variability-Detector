`timescale 1ns/1ps

module tb ();

    reg clk;
    reg rst_n;
    reg sample_valid;
    reg peak_valid;
    wire alert_out;
    wire [9:0] main_baseline_variability;
    wire main_baseline_valid;
    wire [9:0] main_current_variability;
    wire main_variability_valid;

    initial begin
        $dumpfile("tb.fst");
        $dumpvars(0, tb);
    end

    main dut (
        .clk(clk),
        .rst_n(rst_n),
        .sample_valid(sample_valid),
        .peak_valid(peak_valid),
        .alert_out(alert_out),
        .main_baseline_variability(main_baseline_variability),
        .main_baseline_valid(main_baseline_valid),
        .main_current_variability(main_current_variability),
        .main_variability_valid(main_variability_valid)
    );

endmodule
