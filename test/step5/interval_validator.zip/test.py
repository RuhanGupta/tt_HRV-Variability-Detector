import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge


async def start_clock(dut):
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.interval_in.value = 0
    dut.interval_valid.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


async def feed(dut, value, valid=True):
    """Drive interval_in/interval_valid for exactly one clock edge, then
    drop interval_valid low again, with an extra settle edge afterward
    so the caller reads fully-resolved register values (see the
    interval_tracker notes on same-cycle read timing)."""
    dut.interval_in.value = value
    dut.interval_valid.value = 1 if valid else 0
    await RisingEdge(dut.clk)
    dut.interval_valid.value = 0
    await RisingEdge(dut.clk)


@cocotb.test()
async def test_reset_clears_everything(dut):
    await start_clock(dut)
    await reset_dut(dut)
    assert dut.accepted_interval_valid.value == 0
    await RisingEdge(dut.clk)
    assert dut.accepted_interval_valid.value == 0, \
        "valid must stay 0 with no interval_valid activity"


@cocotb.test()
async def test_clearly_valid_interval_accepted(dut):
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 90, valid=True)
    assert dut.accepted_interval_valid.value == 1
    assert int(dut.accepted_interval.value) == 90

    await RisingEdge(dut.clk)
    assert dut.accepted_interval_valid.value == 0, \
        "valid must drop back to 0 the cycle after acceptance"


@cocotb.test()
async def test_lower_boundary_inclusive(dut):
    """Exactly MIN_INTERVAL (30) must be accepted, not rejected."""
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 30, valid=True)
    assert dut.accepted_interval_valid.value == 1, "30 (MIN_INTERVAL) must be accepted"
    assert int(dut.accepted_interval.value) == 30


@cocotb.test()
async def test_just_below_lower_boundary(dut):
    """29 must be rejected."""
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 29, valid=True)
    assert dut.accepted_interval_valid.value == 0, "29 must be rejected"


@cocotb.test()
async def test_upper_boundary_inclusive(dut):
    """Exactly MAX_INTERVAL (200) must be accepted, not rejected."""
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 200, valid=True)
    assert dut.accepted_interval_valid.value == 1, "200 (MAX_INTERVAL) must be accepted"
    assert int(dut.accepted_interval.value) == 200


@cocotb.test()
async def test_just_above_upper_boundary(dut):
    """201 must be rejected."""
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 201, valid=True)
    assert dut.accepted_interval_valid.value == 0, "201 must be rejected"


@cocotb.test()
async def test_valid_invalid_valid_sequence(dut):
    """A rejection must not 'stick' and block the next good interval."""
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 90, valid=True)
    assert dut.accepted_interval_valid.value == 1
    assert int(dut.accepted_interval.value) == 90

    await feed(dut, 10, valid=True)  # too short, rejected
    assert dut.accepted_interval_valid.value == 0, \
        "10 is below MIN_INTERVAL and must be rejected"

    await feed(dut, 95, valid=True)  # good again
    assert dut.accepted_interval_valid.value == 1, \
        "a prior rejection must not block a later good interval"
    assert int(dut.accepted_interval.value) == 95


@cocotb.test()
async def test_ignored_when_interval_valid_low(dut):
    """Garbage on interval_in must be ignored entirely while interval_valid is low."""
    await start_clock(dut)
    await reset_dut(dut)

    dut.interval_in.value = 999  # out of range, and interval_valid never asserted
    dut.interval_valid.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk)
        assert dut.accepted_interval_valid.value == 0, \
            "must never accept anything while interval_valid is low"


@cocotb.test()
async def test_reset_mid_stream(dut):
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 90, valid=True)
    assert dut.accepted_interval_valid.value == 1

    await reset_dut(dut)
    assert dut.accepted_interval_valid.value == 0
    assert int(dut.accepted_interval.value) == 0
