`timescale 1ns/1ps

module tb ();

    reg [9:0] interval_in;
    reg interval_valid;
    reg clk;
    reg rst_n;
    wire [9:0] accepted_interval;
    wire accepted_interval_valid;

    initial begin
        $dumpfile("tb.fst");
        $dumpvars(0, tb);
    end

    interval_validator dut (
        .interval_in(interval_in),
        .interval_valid(interval_valid),
        .clk(clk),
        .rst_n(rst_n),
        .accepted_interval(accepted_interval),
        .accepted_interval_valid(accepted_interval_valid)
    );

endmodule
