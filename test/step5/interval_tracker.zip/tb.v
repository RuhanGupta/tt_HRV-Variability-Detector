`timescale 1ns/1ps

module tb ();

    reg sample_valid;
    reg peak_valid;
    reg clk;
    reg rst_n;
    wire [9:0] interval_out;
    wire interval_valid;

    initial begin
        $dumpfile("tb.fst");
        $dumpvars(0, tb);
    end

    tt_um_ruhangupta_hrv_variability_detector dut (
        .sample_valid(sample_valid),
        .peak_valid(peak_valid),
        .clk(clk),
        .rst_n(rst_n),
        .interval_out(interval_out),
        .interval_valid(interval_valid)
    );

endmodule
