import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge


async def start_clock(dut):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.sample_valid.value = 0
    dut.peak_valid.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


async def pulse_sample(dut, peak=False):
    """Drive sample_valid (and optionally peak_valid) high for exactly
    one clock edge, then drop them low again. An extra settle edge (with
    all inputs low, so no additional sample is counted) is inserted
    afterward so that register updates triggered by this edge are fully
    resolved before the caller reads any outputs."""
    dut.sample_valid.value = 1
    dut.peak_valid.value = 1 if peak else 0
    await RisingEdge(dut.clk)
    dut.sample_valid.value = 0
    dut.peak_valid.value = 0
    await RisingEdge(dut.clk)


@cocotb.test()
async def test_reset_clears_everything(dut):
    """After reset, interval_valid must be low and stay low with no activity."""
    await start_clock(dut)
    await reset_dut(dut)
    assert dut.interval_valid.value == 0, "interval_valid should be 0 right after reset"
    await RisingEdge(dut.clk)
    assert dut.interval_valid.value == 0, "interval_valid should stay 0 with no pulses"


@cocotb.test()
async def test_first_peak_produces_no_interval(dut):
    """The very first peak after reset has nothing to measure against."""
    await start_clock(dut)
    await reset_dut(dut)

    for _ in range(19):
        await pulse_sample(dut, peak=False)

    await pulse_sample(dut, peak=True)  # 20th sample_valid, first peak
    assert dut.interval_valid.value == 0, "first peak must not produce interval_valid=1"

    await RisingEdge(dut.clk)
    assert dut.interval_valid.value == 0, "interval_valid must not go high later either"


@cocotb.test()
async def test_known_separation_50(dut):
    """After the reference peak, 50 sample_valid pulses later, interval should read 50."""
    await start_clock(dut)
    await reset_dut(dut)

    await pulse_sample(dut, peak=True)  # establish reference (first peak)

    for _ in range(49):
        await pulse_sample(dut, peak=False)
    await pulse_sample(dut, peak=True)  # 50th sample_valid is the beat

    assert dut.interval_valid.value == 1, "interval_valid should pulse on the 50th sample"
    assert int(dut.interval_out.value) == 50, \
        f"expected interval_out=50, got {int(dut.interval_out.value)}"

    await RisingEdge(dut.clk)
    assert dut.interval_valid.value == 0, "interval_valid must drop back to 0 the next cycle"


@cocotb.test()
async def test_known_separation_100(dut):
    """Same idea as the 50-sample case, but a 100-sample gap, and chained
    after a previous beat to check the counter reset cleanly."""
    await start_clock(dut)
    await reset_dut(dut)

    await pulse_sample(dut, peak=True)  # reference

    for _ in range(99):
        await pulse_sample(dut, peak=False)
    await pulse_sample(dut, peak=True)

    assert dut.interval_valid.value == 1
    assert int(dut.interval_out.value) == 100, \
        f"expected interval_out=100, got {int(dut.interval_out.value)}"


@cocotb.test()
async def test_minimum_interval_back_to_back(dut):
    """Two beats on consecutive sample_valid pulses, zero samples between them.
    Convention: this should report interval=1, not 0."""
    await start_clock(dut)
    await reset_dut(dut)

    await pulse_sample(dut, peak=True)  # reference peak
    await pulse_sample(dut, peak=True)  # very next sample is also a beat

    assert dut.interval_valid.value == 1
    assert int(dut.interval_out.value) == 1, \
        f"expected interval_out=1 for back-to-back beats, got {int(dut.interval_out.value)}"


@cocotb.test()
async def test_counter_saturation(dut):
    """If sample_valid keeps pulsing with no peak for over 1023 samples,
    the counter must hold at 1023, not wrap around."""
    await start_clock(dut)
    await reset_dut(dut)

    await pulse_sample(dut, peak=True)  # reference peak

    for _ in range(1040):
        await pulse_sample(dut, peak=False)

    await pulse_sample(dut, peak=True)  # finally close it out

    assert int(dut.interval_out.value) == 1023, \
        f"expected saturated interval_out=1023, got {int(dut.interval_out.value)}"


@cocotb.test()
async def test_reset_mid_interval(dut):
    """Resetting partway through counting must clear both the counter and
    have_previous_peak, so the next peak after reset is treated as first-ever."""
    await start_clock(dut)
    await reset_dut(dut)

    await pulse_sample(dut, peak=True)  # establish a reference peak
    for _ in range(10):
        await pulse_sample(dut, peak=False)  # partway through a gap

    await reset_dut(dut)  # reset mid-stream

    await pulse_sample(dut, peak=True)  # should be treated as first peak again
    assert dut.interval_valid.value == 0, \
        "after a mid-stream reset, the next peak must be treated as the first peak"


@cocotb.test()
async def test_chained_sequence(dut):
    """Several beats at different known spacings in a row, checked one by one.
    This is the test most likely to catch an off-by-one in the same-cycle
    increment/report logic, since a single-case test can pass by coincidence."""
    await start_clock(dut)
    await reset_dut(dut)

    await pulse_sample(dut, peak=True)  # reference

    expected_gaps = [50, 30, 200, 1, 10]
    for gap in expected_gaps:
        for _ in range(gap - 1):
            await pulse_sample(dut, peak=False)
        await pulse_sample(dut, peak=True)
        assert dut.interval_valid.value == 1
        assert int(dut.interval_out.value) == gap, \
            f"expected interval_out={gap}, got {int(dut.interval_out.value)}"
