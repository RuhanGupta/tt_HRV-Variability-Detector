import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge


async def start_clock(dut):
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.current_variability.value = 0
    dut.variability_valid.value = 0
    dut.baseline_variability.value = 0
    dut.baseline_valid.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


async def feed(dut, variability, baseline=100, baseline_valid=True, valid=True):
    dut.current_variability.value = variability
    dut.baseline_variability.value = baseline
    dut.baseline_valid.value = 1 if baseline_valid else 0
    dut.variability_valid.value = 1 if valid else 0
    await RisingEdge(dut.clk)
    dut.variability_valid.value = 0
    await RisingEdge(dut.clk)


@cocotb.test()
async def test_no_alert_without_baseline(dut):
    """baseline_valid stays low the whole time, even with clearly-low variability."""
    await start_clock(dut)
    await reset_dut(dut)

    for _ in range(10):
        await feed(dut, 10, baseline=100, baseline_valid=False, valid=True)
    assert dut.alert_out.value == 0, "must never alert without a valid baseline"


@cocotb.test()
async def test_no_alert_during_calibration(dut):
    """Same idea, explicit second test matching the spec's own listed case."""
    await start_clock(dut)
    await reset_dut(dut)

    for _ in range(8):
        await feed(dut, 5, baseline=100, baseline_valid=False, valid=True)
    assert dut.alert_out.value == 0


@cocotb.test()
async def test_one_low_result_does_not_alert(dut):
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 10, baseline=100, baseline_valid=True, valid=True)  # threshold=75, 10 is low
    assert dut.alert_out.value == 0, \
        "a single low reading must not be enough to alert (persistence=4)"


@cocotb.test()
async def test_four_consecutive_lows_trigger_alert(dut):
    """persistence=4: the alert must assert on the 4th consecutive low
    reading, not the 5th."""
    await start_clock(dut)
    await reset_dut(dut)

    for i in range(4):
        await feed(dut, 10, baseline=100, baseline_valid=True, valid=True)
        if i < 3:
            assert dut.alert_out.value == 0, \
                f"alert must not fire before the 4th consecutive low reading (fired after {i+1})"
    assert dut.alert_out.value == 1, \
        "alert must be asserted after exactly 4 consecutive low readings"


@cocotb.test()
async def test_normal_result_resets_count(dut):
    """3 lows (not enough), then 1 normal, then 3 more lows: must never alert."""
    await start_clock(dut)
    await reset_dut(dut)

    for _ in range(3):
        await feed(dut, 10, baseline=100, baseline_valid=True, valid=True)  # low
    await feed(dut, 90, baseline=100, baseline_valid=True, valid=True)      # normal, resets streak
    for _ in range(3):
        await feed(dut, 10, baseline=100, baseline_valid=True, valid=True)  # low again
    assert dut.alert_out.value == 0, \
        "streak was reset by the normal reading; 3 more lows should not be enough to alert"


@cocotb.test()
async def test_equality_boundary(dut):
    """baseline=100 -> threshold=75. Exactly 75 must NOT count as low (strict <).
    74 must count as low."""
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 75, baseline=100, baseline_valid=True, valid=True)
    assert dut.alert_out.value == 0
    # confirm it was treated as a NORMAL reading (not low) by checking it takes
    # a fresh run of 4 lows to alert, i.e. this reading didn't count toward a streak
    for i in range(4):
        await feed(dut, 10, baseline=100, baseline_valid=True, valid=True)
    assert dut.alert_out.value == 1, "75 should not have contributed to the low streak"


@cocotb.test()
async def test_just_below_boundary_counts_as_low(dut):
    await start_clock(dut)
    await reset_dut(dut)

    for _ in range(4):
        await feed(dut, 74, baseline=100, baseline_valid=True, valid=True)
    assert dut.alert_out.value == 1, "74 (just below threshold=75) must count as low"


@cocotb.test()
async def test_auto_clear_on_recovery(dut):
    await start_clock(dut)
    await reset_dut(dut)

    for _ in range(4):
        await feed(dut, 10, baseline=100, baseline_valid=True, valid=True)
    assert dut.alert_out.value == 1

    await feed(dut, 90, baseline=100, baseline_valid=True, valid=True)  # normal reading
    assert dut.alert_out.value == 0, \
        "alert must auto-clear immediately on the next normal reading"


@cocotb.test()
async def test_reset_clears_alert(dut):
    await start_clock(dut)
    await reset_dut(dut)

    for _ in range(4):
        await feed(dut, 10, baseline=100, baseline_valid=True, valid=True)
    assert dut.alert_out.value == 1

    await reset_dut(dut)
    assert dut.alert_out.value == 0
    assert int(dut.dut.low_count.value) == 0


@cocotb.test()
async def test_ignored_when_variability_valid_low(dut):
    """Holding variability_valid low, even with a valid baseline and
    clearly-low data on the wires, must not advance low_count at all."""
    await start_clock(dut)
    await reset_dut(dut)

    dut.baseline_variability.value = 100
    dut.baseline_valid.value = 1
    dut.current_variability.value = 5
    dut.variability_valid.value = 0
    for _ in range(10):
        await RisingEdge(dut.clk)
    assert dut.alert_out.value == 0
    assert int(dut.dut.low_count.value) == 0


@cocotb.test()
async def test_very_first_evaluation_uses_correct_threshold(dut):
    """Regression test: threshold must not be a registered value that lags
    by one cycle. The very first evaluation ever performed, right as
    baseline_valid goes high, must use the CURRENT baseline, not a stale
    or uninitialized threshold register. Feed a clearly-normal value (90,
    real threshold=75) as literally the first thing this module ever
    evaluates, and confirm it's correctly NOT counted as low."""
    await start_clock(dut)
    await reset_dut(dut)

    await feed(dut, 90, baseline=100, baseline_valid=True, valid=True)
    assert int(dut.dut.low_count.value) == 0, \
        "the very first evaluation, given a normal reading, must not increment low_count"
