`timescale 1ns/1ps

module tb ();

    reg [9:0] current_variability;
    reg variability_valid;
    reg [9:0] baseline_variability;
    reg baseline_valid;
    reg clk;
    reg rst_n;
    wire alert_out;

    initial begin
        $dumpfile("tb.fst");
        $dumpvars(0, tb);
    end

    alert_controller dut (
        .current_variability(current_variability),
        .variability_valid(variability_valid),
        .baseline_variability(baseline_variability),
        .baseline_valid(baseline_valid),
        .clk(clk),
        .rst_n(rst_n),
        .alert_out(alert_out)
    );

endmodule
