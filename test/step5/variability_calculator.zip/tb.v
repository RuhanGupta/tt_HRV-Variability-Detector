`timescale 1ns/1ps

module tb ();

    reg [9:0] accepted_interval;
    reg accepted_interval_valid;
    reg clk;
    reg rst_n;
    wire [9:0] current_variability;
    wire variability_valid;

    initial begin
        $dumpfile("tb.fst");
        $dumpvars(0, tb);
    end

    variability_calculator dut (
        .accepted_interval(accepted_interval),
        .accepted_interval_valid(accepted_interval_valid),
        .clk(clk),
        .rst_n(rst_n),
        .current_variability(current_variability),
        .variability_valid(variability_valid)
    );

endmodule
